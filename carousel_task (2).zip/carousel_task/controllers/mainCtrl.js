/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var app = angular.module('app', []);
app.controller('CarouselDemoCtrl', CarouselDemoCtrl);

function CarouselDemoCtrl($scope){
	
	$scope.myInterval = 3000;
	$scope.noWrapSlides = false;
	$scope.activeSlide = 0;
	$scope.displayImage=false;
	$scope.displayCarousel=true;
        $scope.slides1 = [
    {
      image: 'images/image1.jpg'

    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image3.jpg'
    },
    {
      image: 'images/image4.jpg'
    }
];

    $scope.slides2 =  [{
      image: 'images/image5.jpg'
    },
    {
      image: 'images/image6.jpg'
    },
    {
      image: 'images/image7.jpg'
    },
    {
      image: 'images/image8.jpg'
    }
    ];
    


$scope.slides3=[
    {
      image: 'images/image9.jpg'
    },
    {
      image: 'images/image10.jpg'
    }
  ];
 
 
 $scope.showDiv=function(imagePath){
	$scope.displayCarousel=false;
	$scope.imgShow=imagePath;
        $scope.displayImage=true;
  
  }
  
 
}


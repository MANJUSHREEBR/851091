/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var app = angular.module('app', ['ui.bootstrap']);
app.controller('CarouselDemoCtrl', CarouselDemoCtrl);

function CarouselDemoCtrl($scope){
  $scope.myInterval = 3000;
  $scope.noWrapSlides = false;
  $scope.activeSlide = 0;
  $scope.displayImage=false;
  $scope.displayCarousel=true;
  $scope.slides = [
    {
      image: 'images/image1.jpg'

    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image3.jpg'
    },
    {
      image: 'images/image4.jpg'
    },
    {
      image: 'images/image5.jpg'
    },
    {
      image: 'images/image6.jpg'
    },
    {
      image: 'images/image7.jpg'
    },
    {
      image: 'images/image8.jpg'
    },
    {
      image: 'images/image9.jpg'
    },
    {
      image: 'images/image10.jpg'
    }
  ];
 $scope.showDiv=function(index){
 $scope.displayCarousel=false;
 $scope.imgShow=$scope.slides[index].image;
 $scope.displayImage=true;
  
  }
  
}
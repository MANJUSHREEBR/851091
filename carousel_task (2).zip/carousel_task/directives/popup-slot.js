/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('popupSlot', function(dataStore) {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
              
       scope.remove=function(index,x){
          // scope.slotNum.splice(index,1);
            var temp=((parseInt(x.number)*20)/100);
            dataStore.existingNumber =parseInt(dataStore.existingNumber) - temp;
            alert(temp);
            alert(dataStore.existingNumber);
           if(scope.tempId==4){
             dataStore.div4.splice(index,1);

           }
           if(scope.tempId==3){
            dataStore.div3.splice(index,1);
           }
           if(scope.tempId==2){
            dataStore.div2.splice(index,1);
           }
           if(scope.tempId==1){
            dataStore.div1.splice(index,1);

           }
        }
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',
 scope:{
   slotNum:'=' ,
   tempId:'='
  
 },
   //template to be rendered by the directive.

  template: '<div ng-repeat="x in slotNum"><div ng-click="remove($index,x)" style="background-color:{{x.color}};width:{{x.number}};height:50px;float:left;color:white;text-align:center;">{{x.name}}</div>' +
            '</div></div>'
        }
        
    }); 
      
 

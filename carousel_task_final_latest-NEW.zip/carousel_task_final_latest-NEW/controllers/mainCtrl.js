/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('CarouselDemoCtrl',CarouselDemoCtrl);

    CarouselDemoCtrl.$inject =  ['$scope','poolClipService'];
     
    function CarouselDemoCtrl($scope,poolClipService) {
     $scope.slides=[
    {
      image: 'images/image1.jpg',
      image1:'images/not1.jpg'

    },
    {
      image: 'images/image2.jpg',
      image1:'images/not.jpg'

    },
    {
      image: 'images/image3.jpg',
      image1:'images/images.jpg'

    },
    {
      image: 'images/image4.jpg',
      image1:'images/images.jpg'

    },
    {
      image: 'images/image5.jpg',
      image1:'images/images.jpg'

    },
    {
    image: 'images/image6.jpg',
    image1:'images/images.jpg'

    },
    {
      image: 'images/image7.jpg',
     image1:'images/images.jpg'

    },
    {
      image: 'images/image8.jpg',
       image1:'images/images.jpg'

    }
   ];
    duplicate($scope.slides);
   $scope.init=function(){
 poolClipService.getModelInformation()
         .then(function(data) {
                    // promise fulfilled
                    console.log(data);
                    $scope.systemModels=data;
                     $scope.temp=[];
                    for (var i in $scope.systemModels) {
                      $scope.temp.push($scope.systemModels[i]);
                    }
                     console.log($scope.temp);
                     duplicate($scope.temp);
                       
                     
                }, function(error) {
                    // promise rejected, could log the error with: console.log('error', error);
                    console.log('error', error);
                });

    
}
 function duplicate(array){

                if(array.length%4==1)
                 array.splice(array.length-1,0,array[array.length-4],array[array.length-3],array[array.length-2]);
                 if(array.length%4==2)
                 array.splice(array.length-2,0,array[array.length-4],array[array.length-3]);
                 if(array.length%4==3)
                 array.splice(array.length-3,0,array[array.length-4]);  
}
                
 

$scope.changeModel=function(model){
    $scope.ModelName=model;
}
    }

})();









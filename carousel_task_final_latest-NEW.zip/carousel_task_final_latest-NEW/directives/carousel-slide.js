/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {
   'use strict';

    angular
        .module('app')
        .directive('carouselSlide',carouselSlide);

    function  carouselSlide() {
        return {
            restrict: 'AE',
             link: function(scope, element, attrs) {
                 scope.displayCarousel=true;
                   
                  
                 
                 
                  
                 angular.element(element[0].querySelector('.carousel')).carousel({
                 }).on('slid.bs.carousel', function () {
                 var curSlide =  angular.element(element[0].querySelector('.active'));
                 if(curSlide.is( ':first-child' )) {
                    angular.element(element[0].querySelector('.left')).hide();
                    angular.element(element[0].querySelector('.right')).show();
                    return;
                 } 
                 else {
                    angular.element(element[0].querySelector('.left')).show();
                 }
                 if (curSlide.is( ':last-child' )) {
                    angular.element(element[0].querySelector('.right')).hide();
                    return;
                 } 
                 else {
                    angular.element(element[0].querySelector('.right')).show();
                 }
                });


           
                              

                scope.getNumber=function(){
                var temp=[];
                for(var i=0;i<(scope.slides.length)/4;i++){
                temp.push(i); 
                }
                return temp;
             }
             
                scope.change=function(model){
                scope.changeModel()(model);
               } 
           },
            scope:{
               slides: "=slideArray",
             
               modelName:"=",
               tempData:"=",
               changeModel:"&"
            },
            template: '<div class="row"  >'+
                '<div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">'+
                   ' <div class="well" style="cursor:pointer;width:100%;"  ng-click="displayCarousel=!displayCarousel">'+
                        '<span class="glyphicon pull-right glyphicon-chevron-down" ng-if="displayCarousel"></span>'+
                    '<span class="glyphicon pull-right glyphicon-chevron-right" ng-if="!displayCarousel"></span>'+
                    '</div>'+
                    '<div id="carouselWrapper" ng-show="displayCarousel">'+
                      ' <div id="carousel-demo" class="carousel slide" data-ride="carousel" data-interval="false" data-wrap="false">'+
                            '<div class="carousel-inner" >'+ 
                            
                                 '<div ng-class="$index==0 ? \'item active\':\'item\'" ng-repeat="i in getNumber()">'+
                                   '<div ng-repeat="slide in slides track by $index" ng-if="($index >=(($parent.$index)*4)&&$index<(($parent.$index+1)*4))">'+
                                         '<img class="imgIcon" ng-if="modelName !== tempData[$index].name" ng-src={{slide.image}} alt="currant" ng-click="change(tempData[$index].name)" style="cursor:pointer;">'+ 
                                        '<img class="imgIcon" ng-if="modelName == tempData[$index].name" ng-src={{slide.image1}} alt="currant" ng-click="change(tempData[$index].name)" style="cursor:pointer;">'+ 
                                        '<p ng-class="modelName == tempData[$index].name ? \'selectedSystemInfo\':\'\'"><b>{{tempData[$index].name}}</b></p>'+
                                        '<p ng-class="modelName == tempData[$index].name ? \'selectedSystemInfo\':\'\'"><b>{{tempData[$index].drivelimit}}</b></p>'+
                                   '</div>'+
                                '</div>'+ 

                            '</div>'+
                        '</div>'+ 
                          
                       ' <a class="left carousel-control" href="#carousel-demo" data-slide="prev">'+
                            '<span class="glyphicon glyphicon-chevron-left"></span>'+
                        '</a>'+
                        '<a class="right carousel-control" href="#carousel-demo" data-slide="next">'+
                            '<span class="glyphicon glyphicon-chevron-right"></span>'+
                        '</a>'+
                    '</div>'+
                '</div>'+
            '</div>'
        
       }
               
    }
})();


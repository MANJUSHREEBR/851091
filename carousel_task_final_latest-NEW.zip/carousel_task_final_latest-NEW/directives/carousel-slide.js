/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
(function() {
   'use strict';

    angular
        .module('app')
        .directive('carouselSlide',carouselSlide);

    function  carouselSlide() {
        return {
            restrict: 'AE',
             link: function(scope, element, attrs) {
                 
                 scope.displayCarousel=true;
                 scope.sysModel={
                    "Unity 300":{
                        "name":"Unity 300"
                    },
                    "Unity 400":{
                        "name":"Unity 300"
                    },
                    "Unity 500":{
                        "name":"Unity 300"
                    },
                    "Unity 600":{
                        "name":"Unity 300"
                    },
                    "Unity 700":{
                        "name":"Unity 300"
                    },
                    "Unity 800":{
                        "name":"Unity 300"
                    },
                    "Unity 900":{
                        "name":"Unity 300"
                    },
                    "Unity 1000":{
                        "name":"Unity 300"
                    }

                   }
                   scope.a= Object.keys(scope.sysModel);
                   console.log(scope.a);
                  
                 scope.slides=scope.slides1.slice(0);
                 angular.element(element[0].querySelector('.carousel')).carousel({
                 }).on('slid.bs.carousel', function () {
                 var curSlide =  angular.element(element[0].querySelector('.active'));
                 if(curSlide.is( ':first-child' )) {
                    angular.element(element[0].querySelector('.left')).hide();
                    angular.element(element[0].querySelector('.right')).show();
                    return;
                 } 
                 else {
                    angular.element(element[0].querySelector('.left')).show();
                 }
                 if (curSlide.is( ':last-child' )) {
                    angular.element(element[0].querySelector('.right')).hide();
                    return;
                 } 
                 else {
                    angular.element(element[0].querySelector('.right')).show();
                 }
                });


                 if(scope.slides.length%4==1)
                 scope.slides.splice(scope.slides.length-1,0,scope.slides[scope.slides.length-4],scope.slides[scope.slides.length-3],scope.slides[scope.slides.length-2]);
                 if(scope.slides.length%4==2)
                 scope.slides.splice(scope.slides.length-2,0,scope.slides[scope.slides.length-4],scope.slides[scope.slides.length-3]);
                 if(scope.slides.length%4==3)
                 scope.slides.splice(scope.slides.length-3,0,scope.slides[scope.slides.length-4]);
                              

                scope.getNumber=function(){
                var temp=[];
                for(var i=0;i<(scope.slides.length)/4;i++){
                temp.push(i); 
                }
                return temp;
             }
             
                scope.showDiv=function(imagePath){
                scope.modelName=imagePath;
                
               } 
           },
            scope:{
            slides1:'=slideArray',
            imgShow:'='
        },
            template: '<div class="row"  >'+
                '<div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">'+
                   ' <div class="well" style="cursor:pointer;width:100%;"  ng-click="displayCarousel=!displayCarousel">'+
                        '<span class="glyphicon pull-right glyphicon-chevron-down" ng-if="displayCarousel"></span>'+
                    '<span class="glyphicon pull-right glyphicon-chevron-right" ng-if="!displayCarousel"></span>'+
                    '</div>'+
                    '<div id="carouselWrapper" ng-show="displayCarousel">'+
                      ' <div id="carousel-demo" class="carousel slide" data-ride="carousel" data-interval="false" data-wrap="false">'+
                            '<div class="carousel-inner" >'+ 
                                 '<div ng-class="$index==0 ? \'item active\':\'item\'" ng-repeat="i in getNumber()">'+
                                   '<div ng-repeat="slide in slides track by $index" ng-if="($index >=(($parent.$index)*4)&&$index<(($parent.$index+1)*4))">'+

                                        '<img class="imgIcon" ng-if="modelName !== a[$index]" ng-src={{slide.image}} alt="currant" ng-click="showDiv(a[$index])" style="cursor:pointer;">'+ 
                                        '<img class="imgIcon" ng-if="modelName == a[$index]" ng-src={{slide.image1}} alt="currant" ng-click="showDiv(a[$index])" style="cursor:pointer;">'+ 
                                        '<p ng-class="modelName == a[$index] ? \'selectedSystemInfo\':\'\'"><b>{{a[$index]}}</b></p>'+

                                 '</div>'+
                                '</div>'+ 

                            '</div>'+
                        '</div>'+ 
                          
                       ' <a class="left carousel-control" href="#carousel-demo" data-slide="prev">'+
                            '<span class="glyphicon glyphicon-chevron-left"></span>'+
                        '</a>'+
                        '<a class="right carousel-control" href="#carousel-demo" data-slide="next">'+
                            '<span class="glyphicon glyphicon-chevron-right"></span>'+
                        '</a>'+
                    '</div>'+
                '</div>'+
            '</div>'
        
       }
               
    }
})();


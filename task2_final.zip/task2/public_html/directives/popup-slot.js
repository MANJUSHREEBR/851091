/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('popupSlot', function() {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
              
            //console.log(scope.objValue[0].number);
         // console.log(scope.objValue);
          
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',
 scope:{
   slotNum:'=' ,
  
 },
   //template to be rendered by the directive.

  template: '<div ng-repeat="x in slotNum" ><div style="background-color:{{x.color}};width:{{x.number}};height:50px;float:left;">{{x.name}}</div>' +
            '</div></div>'
        }
        
    }); 
      
 

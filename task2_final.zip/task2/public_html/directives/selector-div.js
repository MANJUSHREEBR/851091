/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('selectorDiv', function($localStorage) {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
               
             scope.div1Width=0;
             scope.div2Width=0;
             scope.div3Width=0;
             scope.div4Width=0;
             $localStorage.div1=[];
             $localStorage.div2=[];
             $localStorage.div3=[];
             $localStorage.div4=[];
             scope.numbers=[];
             scope.existingNumber= 0;
             scope.width="0%";
            //    //scope.temp=scope.existingNumber;
               for(i=1;i<=80;i++){
                scope.numbers.push(i);
               }
              
              scope.change=function(){
                   scope.popupOpen=true;
                   scope.numbers=[];
                   scope.existingNumber = parseInt(scope.selectedNumber)+ scope.existingNumber;
                   scope.width=((parseInt(scope.existingNumber)/80)*100)+"%";

                   alert(scope.existingNumber);
                   for(i=1;i<=80-parseInt(scope.existingNumber);i++){
                      scope.numbers.push(i);
                   }
                  //logic for popup blocks
                
                    scope.enteredDetails={color:"",name:"",number:""};
                    scope.enteredDetails.color=scope.slotColor;
                    scope.enteredDetails.name=scope.slotName;
                
                    scope.enteredDetails.number=((scope.selectedNumber/20)*100)+"%";
                     console.log(scope.enteredDetails.number);
                   // scope.dataValue.push(scope.enteredDetails);
                   // $localStorage.details=scope.dataValue;
                    

                   //  scope.numbers=[];
                   scope.div1=$localStorage.div1;
                   scope.div2=$localStorage.div2;
                   scope.div3=$localStorage.div3;
                   scope.div4=$localStorage.div4;

                  if(scope.div1Width<100 && scope.div2Width==0 && scope.div3Width==0 && scope.div4Width==0  ){
                    scope.temp=scope.div1Width;
                     scope.div1Width += parseInt(scope.enteredDetails.number);
                   if(scope.div1Width>100){
                    scope.num=((100)-(scope.temp))+"%";
                    scope.div1.push({"color":scope.slotColor,"name":scope.slotName,"number":scope.num});
                    $localStorage.div1=scope.div1;
                    scope.enteredDetails.number=((scope.div1Width)-(100))+"%";
                    scope.div2Width += ((scope.div1Width)-(100)) ;
                    console.log(scope.div2Width);
                    if(scope.div2Width>100){
                    scope.div2.push({"color":scope.slotColor,"name":scope.slotName,"number":"100%"});
                     scope.div3Width=(scope.div2Width)-100;
                     if(scope.div3Width>100){
                        scope.div3.push({"color":scope.slotColor,"name":scope.slotName,"number":"100%"});
                        scope.div4Width=(scope.div3Width)-100;
                        scope.div4.push({"color":scope.slotColor,"name":scope.slotName,"number":scope.div4Width+"%"});

                        scope.div3Width=100;
                       }
                      else{
                     scope.div3.push({"color":scope.slotColor,"name":scope.slotName,"number":scope.div3Width+"%"});
                        }
                     scope.div2Width=100;
                  
                       
                    }
                    else{
                   scope.div2.push(scope.enteredDetails);}
                    $localStorage.div2=scope.div2;
                    scope.div1Width=100;
    
                  }
                 else if(scope.div1Width<=100){
                  scope.div1.push(scope.enteredDetails);
                  $localStorage.div1=scope.div1;

                  }
                 
                   }
                  else if(scope.div1Width==100 && scope.div2Width<100 && scope.div3Width==0 && scope.div4Width==0){
                  
                    scope.temp=scope.div2Width;
                    scope.div2Width += parseInt(scope.enteredDetails.number);
                    if(scope.div2Width>100){
                    scope.num2=((100)-(scope.temp))+"%";
                   // console.log(scope.num2);
                    scope.div2.push({"color":scope.slotColor,"name":scope.slotName,"number":scope.num2});
                    $localStorage.div2=scope.div2;
                    scope.enteredDetails.number=((scope.div2Width)-(100))+"%";
                    scope.div3Width += ((scope.div2Width)-(100)) ;
                    scope.div3.push(scope.enteredDetails);
                    $localStorage.div3=scope.div3;
                    scope.div2Width=100;
    
                  }
                 else if(scope.div2Width<=100){
                  scope.div2.push(scope.enteredDetails);
                  $localStorage.div2=scope.div2;

                  }
                                   }
                 
                   

                  else if(scope.div1Width==100 && scope.div2Width==100 && scope.div3Width<100 && scope.div4Width==0){
                    scope.temp=scope.div3Width;
                    scope.div3Width += parseInt(scope.enteredDetails.number);
                    if(scope.div3Width>100){
                    scope.num3=((100)-(scope.temp))+"%";
                  
                    scope.div3.push({"color":scope.slotColor,"name":scope.slotName,"number":scope.num2});
                    $localStorage.div3=scope.div3;
                    scope.enteredDetails.number=((scope.div3Width)-(100))+"%";
                    scope.div4Width += ((scope.div3Width)-(100)) ;
                    scope.div4.push(scope.enteredDetails);
                    $localStorage.div4=scope.div4;
                    scope.div3Width=100;
    
                  }
                 else if(scope.div2Width<=100){
                  scope.div3.push(scope.enteredDetails);
                  $localStorage.div3=scope.div3;

                  }
                   }
                  else{
                   // scope.div4Width += parseInt(scope.enteredDetails.number);
                   scope.div4.push(scope.enteredDetails);
                   $localStorage.div3=scope.div4;

                  }
                  
                    
                  alert(scope.div1Width);
                  alert(scope.div2Width);
                  alert(scope.div3Width);
                  alert(scope.div4Width);

                  

                  
                  
                   // scope.existingNumber = parseInt(scope.selectedNumber)+ scope.existingNumber;
                   //   alert(scope.existingNumber);
                    
                   // for(i=1;i<=scope.selectedNumber;i++){
                   //  scope.slotNumbers.push(i);
                   // }
                   // if(scope.existingNumber<=20){
                    
                   //   scope.div1.push(scope.enteredDetails);
                   //   $localStorage.div1=scope.div1;
                   //   scope.div1Width += parseInt(scope.enteredDetails.number);
                   //  console.log(scope.div1Width);
                   //  }
                   
                   //  if(scope.existingNumber>20 && scope.existingNumber<=40){
                   //  if(scope.div1Width<100){
                   //    alert("div1 halffilled");
                   //  scope.num=(100-scope.div1Width)+"%";
                   //  scope.div1.push({"color":scope.slotColor,"name":scope.slotName,"number":scope.num});
                    
                   //  scope.enteredDetails.number=(((scope.selectedNumber/20)*100)-scope.div1Width)+"%";
                   //  scope.div1Width=100;
                   //  scope.div2.push(scope.enteredDetails);
                   //   $localStorage.div2=scope.div2;
                        
                   //  }
                    
                   //  if(((scope.selectedNumber/20)*100)>100)  {
                   //      scope.num=(100-scope.div1Width)+"%";
                   //      scope.div1.push({"color":scope.slotColor,"name":scope.slotName,"number":scope.num});
                   //      $localStorage.div1=scope.div1;

                   //      scope.enteredDetails.number=(((scope.selectedNumber/20)*100)-100)+"%";
                   //      alert(scope.enteredDetails.number);
                   //      console.log(scope.existingNumber);
                   //    scope.div2.push(scope.enteredDetails);
                   //   }      
                   //   if(((scope.selectedNumber/20)*100)<=100){
                   //   scope.div2.push(scope.enteredDetails);
                   //   $localStorage.div2=scope.div2;
                      


                   //   }
                  

                   //  }
                   // // //  if(scope.existingNumber>40 && scope.existingNumber<=60){
                   // //      for(i=1;i<=20;i++){

                   //       scope.div1.push(i);
                   //   }

                   //    for(i=21;i<=40;i++){

                   //       scope.div2.push(i);
                   //  }
                   //    for(i=41;i<=parseInt(scope.existingNumber);i++){

                   //       scope.div3.push(i);
                   //  }
                   

                   //  }
                   //  if(scope.existingNumber>60){

                   //    for(i=1;i<=20;i++){

                   //       scope.div1.push(i);
                   //   }

                   //    for(i=21;i<=40;i++){

                   //       scope.div2.push(i);
                   //  }
                   //    for(i=41;i<=60;i++){

                   //       scope.div3.push(i);
                   //  }
                      
                      
                   //    for(i=61;i<=parseInt(scope.existingNumber);i++){

                   //       scope.div4.push(i);
                   //  }
                   
                   //  }
                   
                   
                   
                   
                  }
              
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',

   //template to be rendered by the directive.
  template: '<div class="col-sm-1"></div><div class="col-sm-6"><input type=color ng-model="slotColor"><input type="text" ng-model="slotName"><select ng-model="selectedNumber"><option ng-repeat="x in numbers track by $index">{{x}}</option>' + 
            '</select><button class="btn btn-info" ng-click="change()">Add</button></div>'
        }
        
    }); 
      
 




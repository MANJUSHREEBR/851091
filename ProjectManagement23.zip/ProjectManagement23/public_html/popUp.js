/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$('#mainContainer').ready(function(){
    debugger;
    //opening feedback modal//
var modal = document.getElementById('myModal');

var mainItem;
// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
    

// When the user clicks the button, open the modal 
//if(btn){
    btn.onclick = function() {
    debugger;
    modal.style.display = "block";
    
}

span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
//window.onclick = function(event) {
//    if (event.target == modal) {
//        modal.style.display = "none";
//    }
//}



//}

// When the user clicks on <span> (x), close the modal

//loadJSON('tableContent.json',
//             function(items) {
//                 debugger;
//                 console.log('items',items); 
//                 mainItem=items;
//                load_data();
//
//
//            },
//             function(xhr) { console.error(xhr); }
//    );
function emptyCheck()
   {
     var empt = document.myform.ta1.value;
if (empt === "")
{
alert("Please input a Value");
return false;
}
else 
{
alert('Feedback has been accepted');
return true; 
}
    } 

//if(document.getElementById('radio1').checked) {
//} else if(document.getElementById('radio2').checked) {
//} else {
//  alert ("You must select a button");
//  return false;
//}
//end of feedback modal

//start of sidenav

replace = function() { 
                        debugger;
                        var home = document.getElementById('Home');
                        var feed = document.getElementById('feed_Back');
                        document.getElementById("Home").style.display="none"; 
                        document.getElementById("feed_Back").style.display="block"
                        document.getElementById("feed_Back").style.visibility="visible"; 
//                        document.getElementById("mainContainer").style.width = "250px";
                    } 
                    
var menuState = 0 
open_Nav = function(){
    debugger;
    if(menuState === 0){
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("header").style.width = "86em";
//    document.getElementById("main").style.marginLeft = "250px";
//       document.getElementById("main1").style.marginLeft = "250px";
        document.getElementById("mainContainer").style.marginLeft = "250px";
        document.getElementById("header").style.marginLeft = "250px";
//        document.getElementById("completePage").style.marginright = "200px";
    document.body.style.backgroundColor = "white";
    document.getElementById("mySidenav").style.position = "fixed";
//    font-size:20px;cursor:pointer;color:white
    menuState++;
    }
    else{
        menuState--;
           document.getElementById("mySidenav").style.width = "0";
            document.getElementById("header").style.width = "100em";
            document.getElementById("header").style.marginLeft = "0";
            document.getElementById("mainContainer").style.marginLeft = "0";
//            document.getElementById("button special").style.marginRight = "-255px";
           //    document.getElementById("main").style.marginLeft= "0";
//    document.getElementById("main1").style.marginLeft= "0";
    document.getElementById("mainContainer").style.marginLeft= "0";
//    document.getElementById("header").style.marginLeft = "-255px";
//    document.body.style.backgroundColor = "white";
    }
}
//end of side nav
//
//
//
//function validateme()
//    {
//     var d=document.forms["myform"]["tarea"].value;
//        if (d==null || d=="")
//        {
//            alert("Please Fill All Required Field");
//            return false;
//        }
//    }
//    

//    function CreateTableFromJSON() {
//       debugger;
//        var myBooks = mainItem;
//
//        var col = [];
//        var table = document.createElement("table");
//        var tr = table.insertRow(-1);
//        for (var i = 0; i < myBooks.items.length; i++) {
//
//            for (var key in myBooks.items[i]) {
//                if (col.indexOf(key) === -1) {
//                    col.push(key);
//                }
//            }
//        }
//        for (var i = 0; i < col.length; i++) {
//            var th = document.createElement("th");      // TABLE HEADER.
//            th.innerHTML = col[i];
//            tr.appendChild(th);
//        }
//
//        for (var i = 0; i < myBooks.items.length; i++) {
//            for (var key in myBooks.items[i]) {
//                if (col.indexOf(key) === -1) {
//                    col.push(key);
//                }
//            }
//        }
//          for (var i = 0; i < myBooks.items.length; i++) {
//
//            tr = table.insertRow(-1);
//
//            for (var j = 0; j < col.length; j++) {
//                var tabCell = tr.insertCell(-1);
//                tabCell.innerHTML = myBooks.items[i][col[j]];
//            }
//        }
//        // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
//        var divContainer = document.getElementById("showData");
//        divContainer.innerHTML = "";
//        divContainer.appendChild(table);
//    }
//


//function loadJSON(path, success, error)
//{
//    debugger;
//    var xhr = new XMLHttpRequest();
//    xhr.onreadystatechange = function()
//    {
//        if (xhr.readyState === XMLHttpRequest.DONE) {
//            if (xhr.status === 200) {
//                if (success)
//               success(JSON.parse(xhr.responseText));
//                    
//            } else {
//                if (error)
//                    error(xhr);
//            }
//        }
//    };
//    xhr.open("GET", 'tableContent.json', true);
//    xhr.send();
//}



//    function checkSpcialChar(event){   
//            if(!((event.keyCode >= 65) && (event.keyCode <= 90) || (event.keyCode >= 97) && (event.keyCode <= 122) || (event.keyCode >= 48) && (event.keyCode <= 57))){
//               event.returnValue = false;
//               return;
//            }
//            event.returnValue = true;
//         }
         
         function blockSpecialChar(e){
        var k;
        document.all ? k = e.keyCode : k = e.which;
        return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }
     
////     function getData()
////     {
////            var xhttp = new XMLHttpRequest();
////            xhttp.onreadystatechange = function() {
////            if (this.readyState == 4 && this.status == 200) {
////                var data=JSON.parse(xhttp.responseText);
////                document.getElementById("showtable").innerHTML = data.Project;
////            }
////            };
////            xhttp.open("GET", "tableContent.json", true);
////            xhttp.send();
////     }
////     function myFunction(xml) {
////          var i;
////          var xmlDoc = xml.responseXML;
////          var table="<tr><th>Artist</th><th>Title</th></tr>";
////          var x = xmlDoc.getElementsByTagName("CD");
////          for (i = 0; i <x.length; i++) { 
////            table += "<tr><td>" +
////            x[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue +
////            "</td><td>" +
////            x[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue +
////            "</td></tr>";
////          }
////          document.getElementById("demo").innerHTML = table;
////     }
//// 
//
//// $(function() {
////
////
////   var people = [];
////
////   $.getJSON('tableContent.json', function(data) {
////       $.each(data.items, function(i, f) {
////          var tblRow = "<tr>" + "<td>" + f.SRNO + "</td>" +
////           "<td>" + f.Project + "</td>" + "<td>" + f.Country + "</td>" + "</tr>";
////           $(tblRow).appendTo("#userdata tbody");
////     });
////
////   });
////
////});

//function load() {
//    debugger;
//	var xhr = new XMLHttpRequest();
//        xhr.open("GET", 'tableContent.json', true);
//        xhr.send();
//        xhr.onreadystatechange = function() {
//    if (this.readyState == 4 && this.status == 200) {
//      document.getElementById("demo").innerHTML = this.responseText;
//        var data = this.responseText;
//        debugger;
//        txt += "<table border='1'>"
//        for (x in myObj) {
//            txt += "<tr><td>" + data.items[x].SRNO + "</td></tr>";
//        }
//        txt += "</table>"        
//        document.getElementById("demo1").innerHTML = table;
//    }
//};
//}
   
   
//  function load(){
//      var mainObj = [
//        {
//            name: "Kapil",
//            age:  21,
//            status: "Active"
//        },
//        {
//            name: "John",
//            age:  28,
//            status: "Inactive"
//        },
//        {
//            name: "Deos",
//            age:  18,
//            status: "Active"
//        }
//    ];
//    var data = '<tbody>'
//    for(i = 0;i < mainObj.length; i++){
//        data+= '<tr>';
//        data+= '<td>' + mainObj[i].name + '</td>';
//        data+= '<td>' + mainObj[i].age + '</td>';
//        data+= '<td>' + mainObj[i].status + '</td>';
//        data+= '</tr>';
//    }
//    data+='</tbody>';
//    document.getElementById('tableData').innerHTML = data;
//   
//  }
//  
//  function load_data(){
//      debugger;
//      
//
//      var mainObj=mainItem;
//      var data = '<tbody>'
//    for(i = 0;i < mainItem.items.length; i++){
//        data+= '<tr>';
//        data+= '<td>' + mainItem.items[i].SRNO + '</td>';
//        data+= '<td>' + mainItem.items[i].Project + '</td>';
//        data+= '<td>' + mainItem.items[i].Country + '</td>';
//        data+= '</tr>';
//    }
//    data+='</tbody>'; 
////    document.getElementById('tableData').innerHTML = data;
//  }

});



        
        

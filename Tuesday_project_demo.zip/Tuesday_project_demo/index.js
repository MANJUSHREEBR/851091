var express = require('express');
var fs = require('fs') ;
var bodyParser = require('body-parser'); 
var app = express();
var path = require('path');

var dataStore=require('nedb');
db= {};
db.detail = new dataStore({filename:'detail'}); 
db.login = new dataStore({filename:'loginDetails'});
db.detail.loadDatabase();
db.login.loadDatabase();

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));

app.post('/Detail', function (req, res) {
	console.log(req.body.from1);
	console.log(req.body.to);
	console.log(req.body.date)
	console.log(req.body.arrival);
	console.log(req.body.departure);
	console.log(req.body.duration);
	console.log(req.body.price);
	console.log(req.body.airline);
	
		
	
		
	db.detail.insert({From:req.body.from1 , To:req.body.to ,date:req.body.date, Arrival:req.body.arrival,Departure:req.body.departure,Duration:req.body.duration,Price:req.body.price, Airline: req.body.airline })
 
}); 


app.get('/getDetails',function(req,res){
	console.log(req.query);	
	console.log(req.query.from);	
	console.log(req.query.to);	
	
	var fromPlace= req.query.from;
	var toPlace = req.query.to	
	
	db.detail.find({From:fromPlace, To:toPlace	}).sort({Departure: 1}).exec(function(err,docs){
		 console.log('start');			
		 console.log(docs);
		 res.send(docs);
	});
	
});   


//generate data to add to datafile
 var loginDetails = [{ Name: "Gagan Patel" , emailId: "gagan@tcs.com", pass: "tcs1"},
					 { Name: "Milind Mahajan" , emailId: "milind@tcs.com", pass: "tcs2"},
					 { Name: "Manju Shree" , emailId: "manju@tcs.com", pass: "tcs3"},
					 { Name: "Mithra K" , emailId: "mitra@tcs.com", pass: "tcs4"}]

// add the generated data to datafile
db.detail.insert(loginDetails, function (err, newDoc) {
	 console.log(newDoc);
});


app.get('/getLoginDetails',function(req,res){
	console.log(req.query);	
	console.log(req.query.emailId);	
	console.log(req.query.pass);	
	
	var email= req.query.emailId;
	var pass = req.query.pass;	
	
	db.detail.find({emailId:email, pass:pass}).sort({emailId: 1}).exec(function(err,docs){
		 
		 res.send(docs);
	});
	
});    
		 
app.listen(process.env.PORT || 8080);
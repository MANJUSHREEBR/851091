#include<iostream>
#include<string>
#include<sstream>
#include<algorithm>
#include "BigInt.h"


BigInt::BigInt() {
number = "0";
sign = false;
}

BigInt::BigInt(vector<int> v){
string final= "";
if(v.size()){
if(v.at(0) < 0){
        sign = true; 	
}
else{
	sign = false;
}
for(int i=0;i < v.size(); i++)
{

if(v[i] < 0 && i!=0){

	cerr << "Negative integer between" <<endl;
	exit(-1);
}

final += to_string(v[i]);
}
number = final;

}
else{
number = "";
sign = false;
}


}

BigInt::BigInt(vector<char> c){
string final = "";
if(c.size()){
if(c.at(0) == '-'){
sign = true;	
}else{
sign = false; 
}
for(int i=0; i < c.size(); i++){
if(isdigit(c[i]) || (i == 0 && c[i] == '-')){
final += c[i];
}
else{
cerr << "invalid character" <<endl;
exit(-1);
}
}
number = final;

}else{
	number = "";
	sign = false;
}

}

BigInt::BigInt(char *c, int size){
	string final = "";
	if(size >0){
		if(c[0] == '-'){
                sign = true;
		}
		else{
                sign = false;
		}
for(int i=0; i < size; i++){
if(isdigit(c[i]) || (i == 0 && c[i] == '-')){
final += c[i];
}
else{
cerr << "invalid character" <<endl;
exit(-1);
}
}
number = final;
}
else{
		number = "";
		sign = false;
	}



}

ostream& operator<<(ostream& osobject, const BigInt& b){
	
osobject << b.number;
return osobject;
}

istream& operator>>(istream& isobject, BigInt& b){
isobject >> b.number;

if(b.number.length() > 0){
if(b.number[0] == '-'){
b.sign = true;
}
else{
b.sign = false;
}

return isobject;
}
}

bool BigInt::operator!() const{
bool final = true;
for(int i=0 ; i < number.size(); i++){
if(number[i] != '0'){
final = false;
break;
}

}
return final;
}

string findSum(string str1, string str2)
{


	// Before proceeding further, make sure length
	// of str2 is larger.
	if (str1.length() > str2.length())
		swap(str1, str2);

	// Take an empty string for storing result
	string str = "";

	// Calculate length of both string
	int n1 = str1.length(), n2 = str2.length();

	// Reverse both of strings
	reverse(str1.begin(), str1.end());
        reverse(str2.begin(), str2.end());

	int carry = 0;
	for (int i=0; i<n1; i++)
	{
		// Do school mathematics, compute sum of
		// current digits and carry
		int sum = ((str1[i]-'0')+(str2[i]-'0')+carry);
		str.push_back(sum%10 + '0');

		// Calculate carry for next step
		carry = sum/10;
	}

	// Add remaining digits of larger number
	for (int i=n1; i<n2; i++)
	{
		int sum = ((str2[i]-'0')+carry);
		str.push_back(sum%10 + '0');
		carry = sum/10;
	}

	// Add remaining carry
	if (carry)
		str.push_back(carry+'0');

	// reverse resultant string
	reverse(str.begin(), str.end());

	return str;
}
bool isSmaller(string str1, string str2)
{
	// Calculate lengths of both string
	int n1 = str1.length(), n2 = str2.length();

	if (n1 < n2)
		return true;
	if (n2 < n1)
		return false;

	for (int i = 0; i < n1; i++)
		if (str1[i] < str2[i])
			return true;
		else if (str1[i] > str2[i])
			return false;

	return false;
}

// Function for find difference of larger numbers
string findDiff(string str1, string str2)
{
	// Before proceeding further, make sure str1
	// is not smaller
	if (isSmaller(str1, str2))
		swap(str1, str2);

	// Take an empty string for storing result
	string str = "";

	// Calculate length of both string
	int n1 = str1.length(), n2 = str2.length();

	// Reverse both of strings
	reverse(str1.begin(), str1.end());
	reverse(str2.begin(), str2.end());

	int carry = 0;

	// Run loop till small string length
	// and subtract digit of str1 to str2
	for (int i = 0; i < n2; i++) {
		// Do school mathematics, compute difference of
		// current digits

		int sub
			= ((str1[i] - '0') - (str2[i] - '0') - carry);

		// If subtraction is less then zero
		// we add then we add 10 into sub and
		// take carry as 1 for calculating next step
		if (sub < 0) {
			sub = sub + 10;
			carry = 1;
		}
		else
			carry = 0;

		str.push_back(sub + '0');
	}

	// subtract remaining digits of larger number
	for (int i = n2; i < n1; i++) {
		int sub = ((str1[i] - '0') - carry);

		// if the sub value is -ve, then make it positive
		if (sub < 0) {
			sub = sub + 10;
			carry = 1;
		}
		else
			carry = 0;

		str.push_back(sub + '0');
	}

	// reverse resultant string
	reverse(str.begin(), str.end());
       auto  it = str.begin();
  
        while (*it == '0')
            str.erase(it);
	if(str == "")
		str = "0";
	return str;
}
string getAbsolute(string s){
if(isdigit(s[0])){
return s;
}
else{
return s.substr(1);
}

}

BigInt BigInt:: operator+(const BigInt& b)const{

BigInt sum;
string n1 = getAbsolute(number);
string n2 = getAbsolute(b.number);

if(sign == b.sign){
	sum.number = findSum(n1, n2);
	if(sum.number != "0")
	sum.sign = sign;
	if(sign == true)
		sum.number.insert(0,1, '-');
}
else{
if(n2 > n1){
sum.number = findDiff(n1, n2);
        if(sum.number != "0")
        sum.sign = b.sign;
        if(sum.sign == true)
            sum.number.insert(0,1, '-');
}
else{
sum.number = findDiff(n2,n1);
        if(sum.number != "0")
        sum.sign = sign;
        if(sign == true)
        sum.number.insert(0,1, '-');
}
}


return sum;
}

BigInt BigInt::operator-(const BigInt& b)const{
	
BigInt Diff;
string n1 = getAbsolute(number);
string n2 = getAbsolute(b.number);

if(sign == b.sign){
Diff.number = findDiff(n1, n2);
}
else{
Diff.number = findSum(n1, n2);
}
if(n1 > n2){
if(number.at(0) == '-' && Diff.number != "0")
Diff.number.insert(0,1, '-');
}
else{
if(b.number.at(0) != '-' && Diff.number != "0"){
Diff.number.insert(0,1, '-');
}
}
return Diff;
}

// Multiplies str1 and str2, and prints result.
string multiply(string num1, string num2)
{
	int len1 = num1.size();
	int len2 = num2.size();
	if (len1 == 0 || len2 == 0)
	return "0";

	// will keep the result number in vector
	// in reverse order
	vector<int> result(len1 + len2, 0);

	// Below two indexes are used to find positions
	// in result.
	int i_n1 = 0;
	int i_n2 = 0;
	
	// Go from right to left in num1
	for (int i=len1-1; i>=0; i--)
	{
		int carry = 0;
		int n1 = num1[i] - '0';

		// To shift position to left after every
		// multiplication of a digit in num2
		i_n2 = 0;
		
		// Go from right to left in num2			
		for (int j=len2-1; j>=0; j--)
		{
			// Take current digit of second number
			int n2 = num2[j] - '0';

			// Multiply with current digit of first number
			// and add result to previously stored result
			// at current position.
			int sum = n1*n2 + result[i_n1 + i_n2] + carry;

			// Carry for next iteration
			carry = sum/10;

			// Store result
			result[i_n1 + i_n2] = sum % 10;

			i_n2++;
		}

		// store carry in next cell
		if (carry > 0)
			result[i_n1 + i_n2] += carry;

		// To shift position to left after every
		// multiplication of a digit in num1.
		i_n1++;
	}

	// ignore '0's from the right
	int i = result.size() - 1;
	while (i>=0 && result[i] == 0)
	i--;

	// If all were '0's - means either both or
	// one of num1 or num2 were '0'
	if (i == -1)
	return "0";

	// generate the result string
	string s = "";
	
	while (i >= 0)
		s += std::to_string(result[i--]);

	return s;
} 

BigInt BigInt::operator*(const BigInt& b1) const {
    BigInt multiplication;
    string n1 = getAbsolute(number);
   string n2 = getAbsolute(b1.number);
   multiplication.number = multiply(n1,n2);
    	if((number.at(0) == '-' || b1.number.at(0) == '-') &&
		(number.at(0) != '-' || b1.number.at(0) != '-' )){
	multiplication.number.insert(0,1, '-');
	multiplication.sign = true;
	}
	else
       multiplication.sign = false;

    return multiplication;
}

bool BigInt::operator==(const BigInt& b) const{
return (number == b.number);
}

bool BigInt::operator>(const BigInt& b) const{
BigInt temp = (*this) - b;
if(temp.number.at(0) == '-' ||  temp.number == "0")
	return false;
else
	return true;
}

bool BigInt::operator>=(const BigInt& b) const{
BigInt temp = (*this) - b;
if(temp.number.at(0) == '-')
        return false;
else
        return true;
}

bool BigInt::operator<(const BigInt& b) const{
BigInt temp = (*this) - b;
if(temp.number.at(0) == '-')
        return true;
else
        return false;
}

bool BigInt::operator<=(const BigInt& b) const{
BigInt temp = (*this) - b;
if(temp.number.at(0) == '-' || temp.number == "0" )
        return true;
else
        return false;
}

BigInt BigInt::operator++(){
	BigInt temp;
	temp.number = "1";
(*this) = (*this) + temp;
return (*this);
}

BigInt BigInt::operator++(int){
BigInt temp = (*this);
BigInt temp1;
temp1.number = "1";
(*this) = (*this) + temp1;
return temp;
}
BigInt BigInt::operator--(){
	BigInt temp;
	temp.number = "1";
(*this) = (*this) - temp;
return (*this);
}
BigInt BigInt::operator--(int){
BigInt temp = (*this);
BigInt temp1;
temp1.number = "1";
(*this) = (*this) - temp1;
return temp;

}



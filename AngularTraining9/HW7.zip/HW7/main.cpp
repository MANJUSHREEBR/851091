#include "BigInt.h" /* Your own header file */
#include <iostream>
#include <vector>

using namespace std;

int main(int argc, const char * argv[]){
    vector<int> integerVector;
    integerVector.push_back(2);
    integerVector.push_back(1);
    integerVector.push_back(0);
    
    vector<char> charVector;
    charVector.push_back('2');
    charVector.push_back('1');
    
    char charArray[] = {'1', '0'};
    
    BigInt A = BigInt(integerVector);
    cout<<"A = "<< A<<endl;
    
    BigInt B = BigInt(charVector);
    cout<<"B = "<<B<<endl;
    
    BigInt C = BigInt(charArray, 2);
    cout<<"C = "<<C<<endl;
    
    BigInt D = B*C;
    
    cout<<"D = "<<D<<endl;
    
    cout<<"A+B = "<<A+B<<endl;
    cout<<"B-C = "<<B-C<<endl;
    
    if(A==D){
        cout<<"A is equal to D "<<A<<endl;
    }
    else {
        cout<<"Ais not equal to D"<<endl;
    }
    
    cout<<"Is A>B? : " <<(A>B)<<endl;
    cout<<"Is B<C? : " <<(B<C)<<endl;
    cout<<"Is A>=D? : " <<(A>=D)<<endl;
    cout<<"Is C<=D? : " <<(C<=D)<<endl;
    cout<<"Post Increment A by 1: " <<A++<<endl;
    cout<<"Post Decrement A by 1: " <<A--<<endl;
    cout<<"Pre Increment A by 1: " <<++A<<endl;
    cout<<"Pre Decrement A by 1: " <<--A<<endl;
    cout<<"What is ! of (A-D)? "<<!(A-D)<<endl;
    
    return 0;
}


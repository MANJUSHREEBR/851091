#include "BigInt.h" /* Your own header file */
#include <iostream>
#include <vector>

using namespace std;

int main(int argc, const char * argv[]){
    vector<int> integerVector;
    integerVector.push_back(0);
    integerVector.push_back(-1);
    integerVector.push_back(6);
    integerVector.push_back(8);
   



    vector<char> charVector;
    charVector.push_back('0');
    charVector.push_back('-');
    charVector.push_back('1');
    charVector.push_back('6');
    charVector.push_back('8');

    char charArray[] = {'0','0', '2','3'};

    BigInt A = BigInt(integerVector);
    cout<<"A = "<< A<<endl;

    BigInt B = BigInt(charVector);
    cout<<"B = "<<B<<endl;

    BigInt C = BigInt(charArray, 4);
    cout<<"C = "<<C<<endl;
    
  BigInt D;
    cout << "Enter a big Integer"<< endl;
    cin >> D;
   cout << "D =" << D << endl;
    cout << "!D = " << !D << endl;
   BigInt E;
   cout << "Enter a big integer"<<endl;
    cin >> E;
    cout << "E =" << E << endl;
    cout << "!E = " << !E << endl;



    
    //BigInt F = D + E;
    cout << "E + D= " << D + E <<endl;

    BigInt G = D - E;
    cout << "D - E = " << G << endl;
     
    BigInt H = D * E;
    cout << "D * E = " << H <<endl;
    
    if(D == E){
	    cout << "D equals E" << endl;
    }
    else{
           cout << "D is not equal to E "<< endl;
    }


    if(D > E){
	    cout << "D is greater than E" << endl;

    }
    else{
             cout << "D is not greater than E" << endl;
    }
    if(D >= E){
           cout << "D is greater or equal than E" << endl;
    }
    else{
        cout << "D is not greater or equal to E" <<endl;
    }
      if(D < E){
           cout << "D is less than E" << endl;
    }
    else{
        cout << "D is not less than  E" <<endl;
    }
    if(D <= E){
           cout << "D is less than or equal than E" << endl;
    }
    else{
        cout << "D is not less than or equal to E" <<endl;
    }
   cout <<"D++ is : " << D++ << endl;
   cout << "++D is: " << ++D << endl;
   cout << "D-- is: " << D-- <<endl;
   cout << "--D is: " << --D << endl;
 
}

#ifndef BIGINT_H
#define BIGINT_H

#include<string>
#include<vector>
using namespace std;

class BigInt{
        friend ostream& operator<<(ostream& osobject, const BigInt&);
	friend istream& operator>>(istream& isobject, BigInt&);
	private:
               string number;
	       bool sign;
	public:

                BigInt();
		BigInt(vector<int> bi);
		BigInt(vector<char> ch);
		BigInt(char* c, int size);
		BigInt operator+(const BigInt&) const;
		BigInt operator-(const BigInt&) const;
		BigInt operator*(const BigInt&) const;
		bool operator==(const BigInt&) const;
		bool operator>(const BigInt&) const;
		bool operator<(const BigInt&) const;
		bool operator>=(const BigInt&) const;
		bool operator<=(const BigInt&) const;
		bool operator!() const;
                BigInt operator--();
		BigInt operator++();
		BigInt operator--(int);
		BigInt operator++(int);

};
#endif 

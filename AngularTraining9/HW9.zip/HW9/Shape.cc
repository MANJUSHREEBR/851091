#include "Shape.h"
#include <cmath>
#include<iostream>
using namespace std;

float distance(XYPoint p1, XYPoint p2){
 return sqrt(pow(p2.x - p1.x, 2) +
                pow(p2.y - p1.y, 2) * 1.0);

}

double Circle::area() {
    return 3.14 * radius * radius;
}

double Triangle::area() {
    float x = distance(a,b);
    float y = distance(b,c);
    float z = distance(c,a);
    float s = (x+y+z)/2;
    double result = sqrt ( s * (s-x) * (s-y) * (s-z) );
    return result;
}

double Rectangle::area() {
    float w = distance(a,b);
    float x = distance(b,c);
    float y = distance(c,d);
    float z = distance(a,d);

    if (w == x && y == z) {
	    cout <<w*y;
        return w*y;
    } else if (w == y && x == z) {
	    cout << w*x;
        return w*x;
    } else if (w == z && x == y) {
	    cout << w*x;
        return w*x;
    }

    return 0;
}



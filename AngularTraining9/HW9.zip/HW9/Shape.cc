#include "Shape.h"
#include <cmath>
#include<iostream>
using namespace std;

double distance(XYPoint p1, XYPoint p2){
 return sqrt(pow(p2.x - p1.x, 2) +
                pow(p2.y - p1.y, 2) * 1.0);

}

double Circle::area() {
    return 3.14 * radius * radius;
}

double Triangle::area() {
    double x = distance(a,b);
    double y = distance(b,c);
    double z = distance(c,a);
    double s = (x+y+z)/2;

    double result = sqrt ( s * (s-x) * (s-y) * (s-z) );
    return result;
}
double max(double s1, double s2, double s3){

if(s1 > s2){

if(s1 >s3)
	return s1;

}
else{
    if(s2 > s3)
	    return s2;

}
return s3;

}

double Rectangle::area() {

    double x = distance(a,b);
    double y = distance(a,c);
    double z = distance(a,d);
    if(x<0 || y<0 || z<0){
       cerr << "not a valid points" << endl;
       return -1;
    }
    double res = max(x,y,z);
    if(res == x){
	return y*z;
    }
    if(res == y){
	    return x*z;
    }
    return x*y;

}



/*double Rectangle::area() {
    double w = distance(a,b);
    double x = distance(b,c);
    double y = distance(c,d);
    double z = distance(a,d);

    if (w == x && y == z) {
        return w*y;
    } else if (w == y && x == z) {
        return w*x;
    } else if (w == z && x == y) {
        return w*x;
    }

    return 0;
}*/



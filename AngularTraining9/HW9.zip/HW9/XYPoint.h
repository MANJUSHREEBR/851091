#ifndef XYPoint_h
#define XYPoint_h

class XYPoint {
public:
    int x;
    int y;
    XYPoint(int xc, int yc) : x(xc), y(yc) {}
};

#endif

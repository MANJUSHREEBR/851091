#include "ShapeSorter.h"
#include <vector>
using namespace std;

void ShapeSorter(vector<Shape *> &shapes) {
    int n = shapes.size();

   for(int i=0;i<n-1; i++){
       for(int j=0;j<n-i-1;j++){
           Shape* temp;
           if(shapes[j]->area() > shapes[j+1]->area()){
              temp = shapes[j];
              shapes[j] = shapes[j+1];
              shapes[j+1] = temp;
           }
       }

   }

}


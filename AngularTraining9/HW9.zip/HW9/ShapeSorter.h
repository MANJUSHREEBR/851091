#ifndef ShapeSorter_h
#define ShapeSorter_h

#include <vector>
#include "Shape.h"

void ShapeSorter(std::vector<Shape *> &shapes);

#endif
#include <iostream>
#include "CircularLinkedList.h"
using std::cout;
using std::endl;

const int points_per_test = 10;

int main() {

    CircularLinkedList circularLinkedList;
    circularLinkedList.push(1, ClockDirection::ClockWise);
    circularLinkedList.push(2, ClockDirection::ClockWise);
    circularLinkedList.push(3, ClockDirection::ClockWise);
    circularLinkedList.push(4, ClockDirection::ClockWise);

    //should print 4,1,2,3 (any notation but this order)
    cout<<circularLinkedList;
    cout << endl;
    circularLinkedList.pop(ClockDirection::ClockWise);
    //should print 1,2,3 (any notation but this order)
    cout<<circularLinkedList;
  cout << endl;

    circularLinkedList.pop(ClockDirection::CounterClockWise);
    //should print 3,2 (any notation but this order)
    cout<<circularLinkedList;
cout << endl;


    CircularLinkedList circularLinkedList2;
    circularLinkedList2.push(1, ClockDirection::ClockWise);
    circularLinkedList2.push(2, ClockDirection::ClockWise);
    circularLinkedList2.push(3, ClockDirection::ClockWise);
    circularLinkedList2.push(4, ClockDirection::ClockWise);
    circularLinkedList2.push(5, ClockDirection::ClockWise);
    circularLinkedList2.push(6, ClockDirection::ClockWise);
    circularLinkedList2.push(7, ClockDirection::ClockWise);
    circularLinkedList2.push(8, ClockDirection::ClockWise);
    //should print 8,1,2,3,4,5,6,7 (any notation but this order)
    cout<<circularLinkedList2;
cout << endl;

    // should print 8
    cout<<circularLinkedList2.peek()<<endl;
cout << endl;

    circularLinkedList2.rotate(4, ClockDirection::ClockWise);

    //should print 4,5,6,7,8,1,2,3 (any notation but this order)
    cout<<circularLinkedList2;
cout << endl;

    circularLinkedList2.rotate(4, ClockDirection::ClockWise);

    //should print 8,1,2,3,4,5,6,7 (any notation but this order)
    cout<<circularLinkedList2;
cout << endl;

}

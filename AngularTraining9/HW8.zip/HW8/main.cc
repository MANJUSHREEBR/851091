#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include "BigInt.h"
using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::vector;

const float points_per_test = 5;

void testTwoBoolean(const string &test_name, bool b1,
                   bool b2, float points_for_this_test,
                   float &total_grade) {

    if (b1 == b2) {
        total_grade += points_for_this_test;
        std::cout << test_name + " succeeded! +" << points_for_this_test << endl;
    } else {
        std::cout << test_name + " failed!" << endl;
    }
}

int main() {

    float total_grade = 0;

//    string test00("Test0.0: Testing << and >>");
//    cout<<"Enter 0123 to create BigInt"<<endl;
//    BigInt cinBigInt;
//    cin>>cinBigInt;
//    cout<<cinBigInt<<endl;
//    vector<int> v0 {1, 2, 3};
//    BigInt b0 = BigInt(v0);
//    testTwoBoolean(test00, cinBigInt == b0, true, points_per_test + points_per_test, total_grade);

//    string test01("Test1.0: Testing equals");
//    vector<int> v11 {2, 1, 0};
//    vector<char> v12 { '2', '1', '0'};
//    BigInt b11 = BigInt(v11);
//    BigInt b12 = BigInt(v12);
//    testTwoBoolean(test01, b11 == b12, true, points_per_test, total_grade);

    string test11("Test1.1: Testing equals with leading zero");
    vector<int> v13 {0,0,0,0,0,0,0,0,0,0,0,0,2, 1, 0};
    char v14[] = {'2','1', '0'};
    BigInt b13 = BigInt(v13);
    BigInt b14 = BigInt(v14, 3);
    testTwoBoolean(test11, b13 == b14, true, points_per_test, total_grade);

    string test02("Test2.0: Testing ! of zero big int");
    vector<int> v21 {0};
    BigInt b21 = BigInt(v21);
    testTwoBoolean(test02, !b21, true, points_per_test, total_grade);

    string test21("Test2.1: Testing ! of non zero big int");
    vector<int> v22 {9,7,5,4,1,4,2,1,4,1,2,1,2,4,5,7,8};
    BigInt b22 = BigInt(v22);
    testTwoBoolean(test21, !b22, false, points_per_test, total_grade);

    string test03("Test3.0: Testing > ");
    vector<int> v31 {9,9,3,4,4,7,5,4,1,4,2,1,4,8,4,7,8,1,2,1,2,4,5,7,8};
    BigInt b31 = BigInt(v31);
    vector<int> v32 {9,7,5,4,6,7,3,5,2,7,3,7,1,4,2,1,4,1,2,1,2,4,5,7,8};
    BigInt b32 = BigInt(v32);
    testTwoBoolean(test03, b31 > b32, true, points_per_test, total_grade);

    string test31("Test3.1: Testing >= ");
    vector<int> v33 {9,7,5,4,6,7,1,4,1,4,2,1,4,8,4,7,8,1,2,1,2,4,5,7,8};
    BigInt b33 = BigInt(v33);
    vector<int> v34 {9,7,5,4,6,7,3,5,2,7,3,7,1,4,2,1,4,1,2,1,2,4,5,7,8};
    BigInt b34 = BigInt(v34);
    testTwoBoolean(test31, b33 >= b34, false, points_per_test, total_grade);

    string test04("Test4.0: Testing < ");
    vector<int> v41 {9,9,8,8,8,8,9,3,4,4,7,5,4,1,4,2,1,4,8,4,7,8,1,2,1,2,4,5,7,8};
    BigInt b41 = BigInt(v41);
    vector<int> v42 {0,0,0,0,0,9,7,5,4,6,7,3,5,2,7,3,7,1,4,2,1,4,1,2,1,2,4,5,7,8};
    BigInt b42 = BigInt(v42);
    testTwoBoolean(test04, b41 < b42, false, points_per_test, total_grade);

    string test41("Test4.1: Testing <= ");
    vector<int> v43 {9,7,5,4,8,7,6,7,1,4,1,4,2,1,4,8,4,7,8,1,2,1,2,4,5,7,8};
    BigInt b43 = BigInt(v43);
    vector<int> v44 {8,8,9,9,7,5,4,6,7,3,5,2,7,3,7,1,4,2,1,4,1,2,1,2,4,5,7};
    BigInt b44 = BigInt(v44);
    testTwoBoolean(test41, b44 <= b43, true, points_per_test, total_grade);

    string test50("Test5.0: Testing pre ++");
    vector<int> v51 {9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9};
    BigInt b51 = BigInt(v51);
    vector<int> v52 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b52 = BigInt(v52);
    testTwoBoolean(test50, ++b51 == b52, true, points_per_test, total_grade);

    string test51("Test5.1: Testing post ++");
    vector<int> v53 {1,2,4,5,2};
    BigInt b53 = BigInt(v53);
    vector<int> v57 {1,2,4,5,2};
    BigInt b57 = BigInt(v57);
    testTwoBoolean(test51, b53++ == b57, true, points_per_test, total_grade);


    string test52("Test5.0: Testing pre --");
    vector<int> v54 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b54 = BigInt(v54);
    vector<int> v55 {9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9};
    BigInt b55 = BigInt(v55);
    testTwoBoolean(test52, --b54 == b55, true, points_per_test, total_grade);

    string test53("Test5.3: Testing post --");
    vector<int> v56 {1,2,4,5,2};
    BigInt b56 = BigInt(v56);
    vector<int> v58 {1,2,4,5,2};
    BigInt b58 = BigInt(v58);
    testTwoBoolean(test53, b56-- == b58, true, points_per_test, total_grade);

    string test06("Test6.0: Testing multiply");
    vector<int> v61 {1,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b61 = BigInt(v61);
    vector<int> v62 {1,0,0,0};
    BigInt b62 = BigInt(v62);
    vector<int> v63 {1,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5,0,0,0};
    BigInt b63 = BigInt(v63);
    testTwoBoolean(test06, b61 * b62 == b63, true, points_per_test, total_grade);

    string test61("Test6.1: Testing multiply");
    vector<int> v64 {-1,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b64 = BigInt(v64);
    vector<int> v65 {1,0,0,0};
    BigInt b65 = BigInt(v65);
    vector<int> v66 {-1,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5,0,0,0};
    BigInt b66 = BigInt(v66);
    testTwoBoolean(test61, b64 * b65 == b66, true, points_per_test, total_grade);

    string test62("Test6.2: Testing multiply");
    vector<int> v67 {-1,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b67 = BigInt(v67);
    vector<int> v68 {-1,0,0,0};
    BigInt b68 = BigInt(v68);
    vector<int> v69 {1,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5,0,0,0};
    BigInt b69 = BigInt(v69);
    testTwoBoolean(test62, b67 * b68 == b69, true, points_per_test, total_grade);

    string test07("Test7.0: Testing adding");
    vector<int> v71 {9,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b71 = BigInt(v71);
    vector<int> v72 {4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b72 = BigInt(v72);
    vector<int> v73 {1,0,2,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b73 = BigInt(v73);
    testTwoBoolean(test07, b71 + b72 == b73, true, points_per_test, total_grade);

    string test71("Test7.1: Testing adding");
    vector<int> v74 {9,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b74 = BigInt(v74);
    vector<int> v75 {-4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b75 = BigInt(v75);
    vector<int> v76 {9,4,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b76 = BigInt(v76);
    testTwoBoolean(test71, b74 + b75 == b76, true, points_per_test, total_grade);

    string test72("Test7.2: Testing adding");
    vector<int> v77 {9,2,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b77 = BigInt(v77);
    vector<int> v78 {-4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b78 = BigInt(v78);
    vector<int> v79 {8,8,4,4,6,7,4,4,0,7,3,7,0,9,5,5,1,6,1,5};
    BigInt b79 = BigInt(v79);
    testTwoBoolean(test72, b77 + b78 == b79, true, points_per_test, total_grade);

    string test08("Test8.0: Testing subtraction");
    vector<int> v81 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b81 = BigInt(v81);
    vector<int> v82 {1,0,0,0};
    BigInt b82 = BigInt(v82);
    vector<int> v83 {-9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0};
    BigInt b83 = BigInt(v83);
    testTwoBoolean(test08, b82 - b81 == b83, true, points_per_test, total_grade);

    string test81("Test8.1: Testing subtraction");
    vector<int> v84 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b84 = BigInt(v84);
    vector<int> v85 {1,0,0,0};
    BigInt b85 = BigInt(v85);
    vector<int> v86 {9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0};
    BigInt b86 = BigInt(v86);
    testTwoBoolean(test81, b84 - b85 == b86, true, points_per_test, total_grade);

    string test82("Test8.2: Testing subtraction");
    vector<int> v87 {-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    BigInt b87 = BigInt(v87);
    vector<int> v88 {-1,0,0,0};
    BigInt b88 = BigInt(v88);
    vector<int> v89 {-9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0};
    BigInt b89 = BigInt(v89);
    testTwoBoolean(test82, b87 - b88 == b89, true, points_per_test, total_grade);

    cout << "TOTAL GRADE=" << total_grade << endl;
}

#ifndef CLOCK_DIRECTION_H
#define CLOCK_DIRECTION_H

enum ClockDirection { ClockWise, CounterClockWise };

#endif
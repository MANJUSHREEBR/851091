#include <iostream>
#include "CircularLinkedList.h"
using std::cout;
using std::endl;

//const int points_per_test = 10;

int main() {

    CircularLinkedList circularLinkedList;
    circularLinkedList.push(1, ClockDirection::ClockWise);
    circularLinkedList.push(2, ClockDirection::ClockWise);
    circularLinkedList.push(-2, ClockDirection::CounterClockWise);
    circularLinkedList.push(5, ClockDirection::CounterClockWise);

    //should print 4,1,2,3 (any notation but this order)
   // cout<<circularLinkedList;
   // cout <<endl;
   // cout <<circularLinkedList.peek() << endl; 
  
     cout << circularLinkedList.pop(ClockDirection::ClockWise) << endl;
    //should print 1,2,3 (any notation but this order)
     cout<<circularLinkedList;
    cout <<endl;
   // cout <<circularLinkedList.peek() << endl;
   // circularLinkedList.rotate(2, ClockDirection::CounterClockWise);
   // cout << circularLinkedList;
   // cout << endl;
   // cout <<circularLinkedList.peek() << endl;

/*    circularLinkedList.pop(ClockDirection::CounterClockWise);
    //should print 3,2 (any notation but this order)
    cout<<circularLinkedList;


    CircularLinkedList circularLinkedList2;
    circularLinkedList2.push(1, ClockDirection::ClockWise);
    circularLinkedList2.push(2, ClockDirection::ClockWise);
    circularLinkedList2.push(3, ClockDirection::ClockWise);
    circularLinkedList2.push(4, ClockDirection::ClockWise);
    circularLinkedList2.push(5, ClockDirection::ClockWise);
    circularLinkedList2.push(6, ClockDirection::ClockWise);
    circularLinkedList2.push(7, ClockDirection::ClockWise);
    circularLinkedList2.push(8, ClockDirection::ClockWise);
    //should print 8,1,2,3,4,5,6,7 (any notation but this order)
    cout<<circularLinkedList2;

    // should print 8
    cout<<circularLinkedList2.peek()<<endl;

    circularLinkedList2.rotate(4, ClockDirection::ClockWise);

    //should print 4,5,6,7,8,1,2,3 (any notation but this order)
    cout<<circularLinkedList2;

    circularLinkedList2.rotate(4, ClockDirection::ClockWise);

    //should print 8,1,2,3,4,5,6,7 (any notation but this order)
    cout<<circularLinkedList2; */
    return 0;

}

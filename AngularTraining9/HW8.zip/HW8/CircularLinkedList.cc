#include "CircularLinkedList.h"

CircularLinkedList::CircularLinkedList(){

head = NULL;

}
CircularLinkedList::~CircularLinkedList(){

delete head;

}
int CircularLinkedList::pop(ClockDirection d){


}

void CircularLinkedList::push(int i, ClockDirection d){

if (head == NULL)
    {
        struct Node* new_node = new Node;
        new_node->data = i;
        new_node->next = new_node->prev = new_node;
        head = new_node;
        return;
}
if (d==0){
struct Node* last = (head)->prev;
struct Node* new_node = new Node;
new_node->data = i;
new_node->prev = last;
new_node->next = head;

(head)->prev = last->next =  new_node;

head = new_node;
}
else{
struct Node* next = (head)->next;
struct Node* new_node = new Node;
new_node ->data = i;
new_node->prev = head;
new_node->next = next;

(head)->next = next->prev = new_node;


}

}


int CircularLinkedList::peek(){


}

void CircularLinkedList::rotate(unsigned int n, ClockDirection d){


}

ostream& operator<<(ostream& osobject,const CircularLinkedList& c){

struct Node *ptr = c.head;
while(ptr->next != c.head){
osobject << (ptr->data);
ptr = ptr->next;
}
osobject << (ptr->data);
return osobject;

}

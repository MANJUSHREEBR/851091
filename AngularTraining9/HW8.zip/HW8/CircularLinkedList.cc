#include "CircularLinkedList.h"
using namespace std;

CircularLinkedList::CircularLinkedList(){

head = NULL;

}
CircularLinkedList::~CircularLinkedList(){

delete head;

}
int CircularLinkedList::pop(ClockDirection d){
if(head == NULL){
	throw std::out_of_range("List is empty");
}
struct Node* last = (head)->prev;
struct Node* next = (head)->next;
struct Node* oldhead = head;

last->next = next;
next->prev = last;
if(d == 0)
head = last;
else
head = next;
return oldhead->data;
}


void CircularLinkedList::push(int i, ClockDirection d){

if (head == NULL)
    {
        struct Node* new_node = new Node;
        new_node->data = i;
        new_node->next = new_node->prev = new_node;
        head = new_node;
        return;
}
if (d==0){
struct Node* last = (head)->prev;
struct Node* new_node = new Node;
new_node->data = i;
new_node->prev = last;
new_node->next = head;

(head)->prev = last->next =  new_node;

head = new_node;
}
else{
struct Node* next = (head)->next;
struct Node* new_node = new Node;
new_node ->data = i;
new_node->prev = head;
new_node->next = next;

(head)->next = next->prev = new_node;
head = new_node;

}

}


int CircularLinkedList::peek(){
if(head == NULL){
        throw std::out_of_range("List is empty");
}
return head->data;

}

void CircularLinkedList::rotate(unsigned int n, ClockDirection d){
if(head == NULL){
        throw std::out_of_range("List is empty");
}
int a = 0;
while(a<n){
	if(d == 0)
head = head->next;
	else
head = head->prev;
a = a + 1;
}

}

ostream& operator<<(ostream& osobject,const CircularLinkedList& c){
if(c.head == NULL){
        throw std::out_of_range("List is empty");
}
struct Node *ptr = c.head;
while(ptr->prev != c.head){
osobject << (ptr->data);
ptr = ptr->prev;
}
osobject << (ptr->data);
return osobject;

}

#ifndef CIRCULAR_LINKED_LIST
#define CIRCULAR_LINKED_LIST



#include<iostream>
#include "ClockDirection.h"
using namespace std;

/*class Node
{
public:
    int data;
    struct Node *next; // Pointer to next node
    struct Node *prev; // Pointer to previous node
    Node()
    {
      data = 0;
      next = NULL;
      prev = NULL;
   }

};*/
struct Node
{
    int data;
    struct Node *next;
    struct Node *prev;
};

class CircularLinkedList{
	public: 

		CircularLinkedList();
		~CircularLinkedList();
		void push(int i, ClockDirection d);
		int pop(ClockDirection d);
		int peek();
		void rotate(unsigned int n, ClockDirection d);
               friend ostream& operator<<(ostream& osobject,const CircularLinkedList&);
	private:
	    struct Node *head;
            
};

#endif

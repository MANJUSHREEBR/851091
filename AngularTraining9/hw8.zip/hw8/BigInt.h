 Boolb

#ifndef SAI_BIGINT_H
#define SAI_BIGINT_H



#include<string>
#include<vector>


using namespace std;

class BigInt{

private:
    string num;

    bool signature;

    string add(string num1, string num2);

    string subtract(string num1, string num2);


    bool equals(BigInt b1, BigInt b2);

    bool less(BigInt b1, BigInt b2);

    bool greater(BigInt b1, BigInt b2);

    string multiply(string num1, string num2);

public:
    BigInt();
    BigInt(string s);
    BigInt(int n);
    BigInt(string s, bool sign);
    BigInt(vector<int> d);
    BigInt(vector<char> d);
    BigInt(char *p, int size);
    operator string(); // for conversion from BigInt to string

    void setSignature(bool s);

    void setNum(string s);

    const string &getNum(); // get the number value

    const bool &getSignature();   // get the signature value

    BigInt absolute(); // returns the absolute value

    BigInt operator+(BigInt b1);
    BigInt operator-(BigInt b1);
    BigInt operator*(BigInt b1);

    void operator=(BigInt b1);

    bool operator==(BigInt b1);

    bool operator>(BigInt b1);

    bool operator>=(BigInt b1);

    bool operator<(BigInt b1);

    bool operator<=(BigInt b1);
    
      BigInt  operator--(int);
       BigInt operator++(int);
    bool operator!();


    BigInt & operator++();
    BigInt & operator--();
   


    friend ostream& operator<< (ostream &out, const BigInt &c);
    friend istream& operator>> (istream &in, BigInt &c);



};


#endif //SAI_BIGINT_H

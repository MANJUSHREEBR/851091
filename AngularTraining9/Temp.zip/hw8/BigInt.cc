

#include <string>
#include<iostream>
#include<sstream>

#include "BigInt.h"

BigInt::BigInt() {
    num = "0";
    signature = false;
}

BigInt::BigInt(string s) {
    if (isdigit(s[0])) {  // if not signed
        setNum(s);
        signature = false; // +ve
    } else {
        setNum(s.substr(1));
        signature = (s[0] == '-');
    }
}

BigInt::BigInt(string s, bool sign) {
    setSignature(sign);
    setNum(s);
}


BigInt::BigInt(int p) {
    string t;
    stringstream ss;
    ss << p;
    ss >> t;
    if (isdigit(t[0])) {
        setNum(t);
        setSignature(false); // positive
    } else {
        setNum(t.substr(1));
        setSignature(t[0] == '-');
    }

}

BigInt::BigInt(vector<int> s) {
    string res = "";
    if (s.size() > 0) {
        if (s.at(0) >= 0) {
            for (auto &elem : s) {   // use normal for loop for iterating
                stringstream ss;
                if (elem < 0) {
                    cerr << "Negative integer between vector" << endl;
                    exit(0);
                }
                ss << elem;
                res += ss.str();
            }
            num = res;
            signature = false;
        } else {
            res = to_string(s.front() * -1);
            for (auto &elem : s) {
                stringstream ss;
                if (elem < 0) {    // to check its a vector of integers .. so int shouldn't be less than 0 ;
                    cerr << "Negative integer between vector" << endl;
                    exit(0);
                }
                ss << elem;
                res += ss.str();
            }
            num = res;
            signature = true;
        }
    } else {
        num = "0";
        signature = false;
    }
}


BigInt::BigInt(char *p, int sz) {
    if (sz > 0) {
        string res;

        // have a check is digit or not
        if (isdigit(p[0])) {
            for (int k = 0; k < sz; k++) {
                if (isdigit(p[k])) {
                    res += p[k];
                } else {
                    cerr << "Invalid character encountered" << endl;
                    exit(0);
                }
            }
            setNum(res);
            signature = false;
        } else {
            for (int k = 1; k < sz; k++) {
                if (isdigit(p[k])) {
                    res += p[k];
                } else {
                    cerr << "Invalid character encountered" << endl;
                    exit(0);
                }
            }
            setNum(res);
            signature = true;
        }
    } else {
        setNum("0");
        setSignature(false);
    }
}

BigInt::BigInt(vector<char> s) {
    string result = "";
    if (s.size() > 0) {
        if (s.at(0) == '-') {
            if (s.size() > 1) {
                for (vector<char>::iterator it = s.begin() + 1; it != s.end(); ++it) {
                    if (isdigit(*it)) {
                        result += *it;
                    } else {
                        cerr << "Invalid  Character";
                        exit(0);
                    }
                }
                while (result[0] == '0' && result.length() != 1)
                    result.erase(0, 1);
                num = result;
                signature = true;
            } else {
                cerr << "Invalid Character";
                exit(0);
            }
        } else if (s.at(0) == '+') {
            if (s.size() > 1) {
                for (vector<char>::iterator it = s.begin() + 1; it != s.end(); ++it) {
                    if (isdigit(*it)) {
                        result += *it;
                    } else {
                        cerr << "Invalid  Character";
                        exit(0);
                    }
                }
                while (result[0] == '0' && result.length() != 1)
                    result.erase(0, 1);
                num = result;
                signature = false;
            } else {
                cerr << "Invalid Characters";
                exit(0);
            }
        } else {

            for (vector<char>::iterator it = s.begin(); it != s.end(); ++it) {
                if (isdigit(*it)) {
                    result += *it;
                } else {
                    cerr << "Invalid Character";
                    exit(0);
                }
            }
            while (result[0] == '0' && result.length() != 1)
                result.erase(0, 1);
            num = result;
            signature = false;
        }
    } else {
        num = "0";
        signature = false;
    }
}

// setters and getters for the num and signature

void BigInt::setNum(string s) {
    num = s;
}

const string &BigInt::getNum() {
    return num;
}

void BigInt::setSignature(bool s) {
    signature = s;
}

const bool &BigInt::getSignature() {
    return signature;
}


// let's over load the friend functions  >>

istream &operator>>(istream &in, BigInt &c) {
    cout << "Number Please" << endl;
    string s;
    in >> s;
    if (s.length() > 0) {
        if (s[0] == '-') {
            c.setNum(s.substr(1));
            c.setSignature(true);
        } else {
            c.setNum(s);
            c.setSignature(false);
        }
    } else {
        c.setNum("0");
        c.setSignature(false);
    }
    return in;
}

//  let's over load the friend functions <<
ostream & operator<<(ostream &out, const BigInt &c) {
    string g = "";
    if (c.signature) {
        g = "-";
    }
    out << g << c.num;
    return out;
}


BigInt BigInt::absolute() {
    return BigInt(getNum());
}
// lets overload basic =,-,*

bool BigInt::operator!() {
    if ((*this).num == "0") {
        return true;
    }
    return false;

}

BigInt BigInt::operator+(BigInt b1) {
    BigInt adding;
    if (getSignature() ==clearcl) {
        adding.setNum(add(getNum(), b1.getNum()));
        adding.setSignature(getSignature());
    } else {
        if (absolute() > b1.absolute()) {
            adding.setNum(subtract(getNum(), b1.getNum()));
            adding.setSignature(getSignature());
        } else {
            adding.setNum(subtract(b1.getNum(), getNum()));
            adding.setSignature(b1.getSignature());
        }
    }
    if (adding.getNum() == "0") {
        adding.setSignature(false);
    }
    return adding;
}

BigInt BigInt::operator-(BigInt b1) {
    b1.setSignature(!b1.getSignature());
    return (*this) + b1;
}

BigInt BigInt::operator*(BigInt b1) {
    BigInt multiplication;
    multiplication.setSignature(getSignature() != b1.getSignature());
    multiplication.setNum(multiply(getNum(), b1.getNum()));
    if (multiplication.getNum() == "0") {
        multiplication.setSignature(false);
    }
    return multiplication;
}

void BigInt::operator=(BigInt b1) {
    setNum(b1.getNum());
    setSignature(b1.getSignature());
}

bool BigInt::operator==(BigInt b1) {
    return equals((*this), b1);
}

bool BigInt::operator>(BigInt b1) {
    return greater((*this), b1);
}

bool BigInt::operator>=(BigInt b1) {
    return greater((*this), b1) || equals((*this), b1);
}


bool BigInt::operator<(BigInt b) {
    return less((*this), b);
}


bool BigInt::operator<=(BigInt b1) {
    return equals((*this), b1) || less((*this), b1);
}

// lest overload the ++,--
BigInt &BigInt::operator++() {
    (*this) = (*this) + 1;
    return (*this);
}


BigInt &BigInt::operator--() {
    (*this) = (*this) - 1;
    return (*this);

}

// lest overload the ++,-- with int value
BigInt BigInt::operator++(int) {
    BigInt prev = (*this);
    (*this) = (*this) + 1;
    return prev;
}

BigInt BigInt::operator--(int) {
    BigInt prev = (*this);
    (*this) = (*this) - 1;
    return prev;
}
// the private methods
¬


BigInt::operator string() {
    string sString = (getSignature()) ? "-" : "";
    sString += num;
    return sString;
}


string BigInt::subtract(string num1, string num2) {
    string sub = (num1.length() > num2.length()) ? num1 : num2;
    int diffInLength = abs((int) (num1.size() - num2.size()));

    if (num1.size() > num2.size()) {
        num2.insert(0, diffInLength, '0');

    } else {
        num1.insert(0, diffInLength, '0');
    }
    for (int k = num1.length() - 1; k >= 0; --k) {
        if (num1[k] < num2[k]) {
            num1[k] += 10;
            num1[k - 1]--;
        }
        sub[k] = ((num1[k] - '0') - (num2[k] - '0')) + '0';
    }

    while (sub[0] == '0' && sub.length() != 1) {
        sub.erase(0, 1);
    }
    return sub;
}

bool BigInt::equals(BigInt b1, BigInt b2) {
    return b1.getSignature() == b2.getSignature() && b1.getNum() == b2.getNum();

}

bool BigInt::less(BigInt b1, BigInt b2) {
    bool signature1 = b1.getSignature();
    bool signature2 = b2.getSignature();

    if (!signature1 && signature2)
        return false;

    else if (signature1 && !signature2)
        return true;

    else if (!signature1) {
        if (b1.getNum().length() > b2.getNum().length())
            return false;
        if (b1.getNum().length() < b2.getNum().length())
            return true;
        return b1.getNum() < b2.getNum();
    } else {
        if (b1.getNum().length() < b2.getNum().length())
            return false;
        if (b1.getNum().length() > b2.getNum().length())
            return true;

        return b1.getNum().compare(b2.getNum()) > 0;
    }
}

bool BigInt::greater(BigInt b1, BigInt b2) {
    return !less(b1, b2) && !equals(b1, b2);
}

// multiply  method

string BigInt::multiply(string num1, string num2) {
    string result = "0";
    if (num1.length() < num2.length())
        num2.swap(num1);

    for (int k = num1.length() - 1; k >= 0; --k) {
        string temp = num2;
        int cDigit = num1[k] - '0';
        int carry = 0;

        for (int p = temp.length() - 1; p >= 0; --p) {
            temp[p] = ((temp[p] - '0') * cDigit) + carry;

            if (temp[p] > 9) {
                carry = (temp[p] / 10);
                temp[p] -= (carry * 10);
            } else
                carry = 0;

            temp[p] += '0';
        }

        if (carry > 0)
            temp.insert(0, reinterpret_cast<const char *>(1), (carry + '0'));

        temp.append((num1.length() - k - 1), '0');

        result = add(result, temp);

    }

    while (result[0] == '0' && result.length() != 1)
        result.erase(0, 1);

    return result;
}

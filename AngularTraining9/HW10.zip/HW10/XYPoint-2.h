
#ifndef SAI_XYPOINT_H
#define SAI_XYPOINT_H

#include<iostream>
#include<cmath>
#include<vector>

using namespace std;

class XYPoint {
public:
    XYPoint();

    XYPoint(const XYPoint &obj);

    XYPoint(const double &xp, const double &yp);

    double getX() {
        return x;
    };

    double getY() {
        return y;
    };

    bool operator<(XYPoint obj1);

    bool operator>(XYPoint obj1);

    bool operator==(XYPoint obj1);

    bool operator>=(XYPoint obj1);

    bool operator<=(XYPoint obj1);

    float distanceToOrigin();

    float distanceBtwPoints(XYPoint obj);


private:

    double x, y;

    bool equals(XYPoint obj1, XYPoint obj2);

    bool greater(XYPoint obj1, XYPoint obj2);


};

class Shape{
public:
    virtual double area() = 0;

};


class Circle : public Shape{
private:
    XYPoint point;
    int r;
public:
    Circle();
    Circle(const XYPoint p, int radius);
    double area();
};

class Rectangle : public Shape{
private:
    XYPoint p1;
    XYPoint p2;
    XYPoint p3;
    XYPoint p4;
public:
    Rectangle();
    Rectangle(const XYPoint point1, const XYPoint point2,const XYPoint point3,const XYPoint point4);
    double area();
};


class Triangle : public Shape{
private:
    XYPoint p1;
    XYPoint p2;
    XYPoint p3;

public:
    Triangle();
    Triangle(const XYPoint point1, const XYPoint point2,const XYPoint point3);
    double area();
};


void ShapeSorter(vector<Shape *> &shapes);


#endif //SAI_XYPOINT_H

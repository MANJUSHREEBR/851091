

#include <cmath>
#include "XYPoint.h"


XYPoint::XYPoint() {
    x = 0;
    y = 0;
}

XYPoint::XYPoint(const XYPoint &obj) {
    x = obj.x;
    y = obj.y;
}

XYPoint::XYPoint(const double &xp, const double &yp) {
    x = xp;
    y = yp;
}

bool XYPoint::operator<(XYPoint obj1) {
    return (!((*this) > obj1) && !((*this) == obj1));
}

bool XYPoint::operator>(XYPoint obj1) {
    return greater((*this), obj1);
}

bool XYPoint::operator==(XYPoint obj1) {
    return equals((*this), obj1);
}

bool XYPoint::operator>=(XYPoint obj1) {
    return (*this) == obj1 || (*this) > obj1;
}

bool XYPoint::operator<=(XYPoint obj1) {
    return (*this) == obj1 || (*this) < obj1;
}

float XYPoint::distanceToOrigin() {
    float result;
    result = sqrt(pow((*this).x, 2) + pow((*this).y, 2));
    return result;
}

float XYPoint::distanceBtwPoints( XYPoint obj) {
    float result;
    double x1 = (*this).x - obj.x;
    double y1 = (*this).y - obj.y;
    result = sqrt(pow(x1, 2) + pow(y1, 2));
    return result;
}

bool XYPoint::equals(XYPoint obj1, XYPoint obj2) {
    return obj1.getX() == obj2.getX() && obj1.getY() == obj2.getY();
}


bool XYPoint::greater(XYPoint obj1, XYPoint obj2) {
    float dist1 = obj1.distanceToOrigin();
    float dist2 = obj2.distanceToOrigin();
    return dist1 > dist2;
}


Circle::Circle() {
    point = XYPoint(0, 0);
    r=0;
}

Circle::Circle(const XYPoint p, int radius){
    point = p;
    r=radius;
}

double Circle::area() {
    return 3.14 * r * r;
}

Triangle::Triangle() {
    p1 = XYPoint(0, 0);
    p2 = XYPoint(0, 0);
    p3 = XYPoint(0, 0);
}

Triangle::Triangle(const XYPoint point1, const XYPoint point2, const XYPoint point3) {
    p1 = point1;
    p2 = point2;
    p3 = point3;
}

double Triangle::area() {
    float a = p1.distanceBtwPoints(p2);
    float b = p2.distanceBtwPoints(p3);
    float c = p3.distanceBtwPoints(p1);
    float s = (a+b+c)/2;
    double result = sqrt ( s * (s-a) * (s-b) * (s-c) );
    return result;
}

Rectangle::Rectangle() {
    p1 = XYPoint(0, 0);
    p2 = XYPoint(0, 0);
    p3 = XYPoint(0, 0);
}

Rectangle::Rectangle(const XYPoint point1, const XYPoint point2, const XYPoint point3, const XYPoint point4) {
    p1 = point1;
    p2 = point2;
    p3 = point3;
    p4 = point4;
}

double Rectangle::area() {
    float a = p1.distanceBtwPoints(p2);
    float b = p2.distanceBtwPoints(p3);
    float c = p3.distanceBtwPoints(p4);
    float d = p4.distanceBtwPoints(p1);

    if (a == b && c == d) {
        return a*c;
    } else if (a == c && b == d) {
        return a*b;
    } else if (a == d && b == c) {
        return a*b;
    }

    return 0;
}


void ShapeSorter(vector<Shape *> &shapes) {
    int n = shapes.size();

   for(int i=0;i<n-1; i++){
       for(int j=0;j<n-i-1;j++){
           Shape* temp;
           if(shapes[j]->area() > shapes[j+1]->area()){
              temp = shapes[j];
              shapes[j] = shapes[j+1];
              shapes[j+1] = temp;
           }
       }

   }

}

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var app = angular.module("myApp", []);
       app.controller("myCtrl", function($scope,colorFactory) {
       $scope.mergeColor=function(){
              $scope.color3= colorFactory.mergeColor($scope.mainColor,$scope.mainColor2); 
              alert($scope.color3);
             }
      
         $scope.bgClr="pink";
         $scope.bgClr1="#FFA500";
         $scope.bgClr2="yellow";
         $scope.change1=function(){
           $scope.bgClr1="black";
         }
         $scope.change2=function(){
          $scope.bgClr="red";
         }
          $scope.change3=function(){
          colorFactory.mergeColor($scope.bgClr,$scope.bgClr1);
         }
        });
 
      
     app.directive('sampleDiv', function() {
       return {
           link:function(scope){
                scope.changeClr=function(){
                 //scope.bgClr="black";
                // scope.modelValue="red";
                 scope.changeColor();
                }
                
            },
           controller:"directiveCtrl",
       restrict: 'E',
       scope:{
           showTxtfield:'=',
           showClrfield:'=',
           modelValue:'=',
           changeColor:'&'
           
           
          },
       template: '<div class="col-sm-6" style="background-color:{{modelValue}}">\n\
      <input type="text" ng-model="backgrnd" ng-if="showTxtfield"><input type="color" ng-if="showClrfield" ng-model="div1Background" >\n\
      <input type="button" class="btn btn-primary" ng-click="changeClr()" value="changeColor"><div>hai{{backgrnd}} </div></div>'
        }
        
    }); 
      
 app.controller("directiveCtrl", function($scope) {
      
      
     });

// Factory
app.factory('colorFactory', function(){
    return {
        mergeColor: function(color1,color2){
         var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(color2);
         var result2=  /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(color1);
         var clr1= result ? {
         r: parseInt(result[1], 16),
         g: parseInt(result[2], 16),
         b: parseInt(result[3], 16)
          }: null;
         var clr2= result2 ? {
         r: parseInt(result2[1], 16),
         g: parseInt(result2[2], 16),
         b: parseInt(result2[3], 16)
          }: null;
        
        var red=Math.round(clr1.r+clr2.r /2);
        var blue=Math.round(clr1.g+clr2.g /2);
        var green=Math.round(clr1.b+clr2.b /2);
        
        return "rgb("+red+","+blue+","+green+")";
        
        }  
    }               
});
 





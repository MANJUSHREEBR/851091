#include<iostream>
using namespace std;

class baseclass{

	public:
	virtual	void print(){ cout << "base print"<<endl;};

};

class derivedclass: public baseclass{

public:
	void print(){cout << "derived print" <<endl;};


};
void callprint(baseclass &b){

b.print();

}

int main()
{
 baseclass bobj;
 derivedclass dobj;

callprint(bobj);
callprint(dobj);


return 0;
}

#include<iostream>
using namespace std;

class dynamicArray{
 private:
 int* p;
 int length;
 int maxsize;
 
 public:
 const dynmaicArray& operator=(const dynamicArray&);

void print() const;
void insertAt(int location, const int &insertitem);
int getelm(int location) const;
dynamicArray(int size = 100);
~dynamicArray();


//copy constructor 
dynamicArray(const dynamicArray& otherlist);
};

//class definitions
void dynamicArray::print() const{
for(int i =0; i < length; i++)
cout << p[i]<<endl;
}

void dynamicArray::insertAt(int location. const int& insertitem){
if(location < 0 || location >= maxsize)
cerr << "position is out of range" << endl;
else if (length >= maxsize)
cerr << "cannot insert in a full list"<<endl;
else{
for(int i = length; i > location; i--)

p[i] = p[i-1];
p[location] = insertitem;
length ++;
}
}

dynamicarray::dynamicArray(int size){
if(size < 0){
maxsize = 100;
}
else{
maxsize = 0;
}
length = 0;
p = new int[maxsize];
assert(list != NULL);
}

dynamicArray::~dynamicArray(){
delete [] p;
}

int dynamicArray::getelm(int index) const{
return p[index];
}

//copy constructor
dynamicArray::dynamicArray(const dynamicArray& otherList){

maxsize = otherList.maxsize;
length = otherList.length;
p = new int[maxsize];
assert(p != NULL);
for(int j=0; j<length; j++)
p[j] = otherList.p[j];
}
//overload of assignment operator
const dynamicArray& dynamicArray::operator=(const dynamicArray& otherList){

if(this != &otherList){
delete [] p;
maxsize = otherList.maxsize;
length = otherList.length;
p = new int[maxsize];
assert(p != NULL);
for(int i = 0; i< length;i++)
p[i] = otherList.p[i];
}

return *this;
}

int main(){
int *p;

dynamicArray d1(15, p);

d1.setArray(4, 5);
d1.getArray(5);

//cout << d1.p[i];







return 0;
}

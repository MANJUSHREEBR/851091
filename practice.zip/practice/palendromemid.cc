#include<iostream>
using namespace std;
#include<string>

void checkpalendrome(string str){
	bool  palen = true; 

	for(int i = 0; i< str.size()/2; i++){
		if(str[i] != str[str.size() -i -1]){
			palen = false;
			break;
		}
		
	}

if(palen)
	cout << "string is palendrome";
else
	cout << "string is not a palendrome:'";





}




int main(){

string s = "maam";

checkpalendrome(s);







return 0;
}

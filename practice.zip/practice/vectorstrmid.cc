#include<iostream>
using namespace std;

#include<vector>
#include<string>



void reversevect(vector<string> &str){

for(int i = 0; i< str.size(); i++){
	
 for(int j = 0; j< str[i].size()/2; j++){
  char temp;
  temp = str[i][j];
  str[i][j] = str[i][str[i].size()- j -1 ];
  str[i][str[i].size() - j -1 ] = temp;
 }

	
}
 
}

int main(){

vector<string> v = {"manju", "kavya" , "raghu", "sadhu"};


reversevect(v);



for(int i =0;  i< v.size() ; i++){

	cout << " " << v.at(i);

}
























return 0;
}


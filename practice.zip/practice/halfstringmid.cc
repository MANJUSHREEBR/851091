#include<iostream>
using namespace std;
#include<string>
void halfstring(string str,string &s1,string &s2){
 for( int i = 0; i < str.size(); i++){

    if( i < str.size()/2)
         s1 = s1 + str[i];
    else 
        s2 = s2 + str[i];




}
}
int main(){
string s1 = "manjuragh";
string s3 = "";
string s4 = "";

halfstring(s1,s3,s4);

cout << s3 << " " << s4 <<endl;



return 0;
}

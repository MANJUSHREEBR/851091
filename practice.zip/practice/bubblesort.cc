#include<iostream>
using namespace std;

void swap(int &a, int &b){
	int temp = a;
	a = b;
	b = temp;
}
void bubblesort(int a[], int n){
for(int i = 0 ; i < n; i++){
	for(int j = 0; j < (n-i-1);j++){
               if(a[j] > a[j+1])
		       swap(a[j], a[j+1]);

	}
}

}


int main(){

int array[] = {12,66,78,89,33,32,12};
int len = sizeof(array)/sizeof(array[0]);

bubblesort(array, len);

for(int i=0 ; i < len ; i++){
cout << array[i] <<endl;
}
return 0;
}

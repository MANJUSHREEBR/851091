#include<iostream>
#include<cmath>
using namespace std;


class XYpoint{

 friend ostream& operator<<(ostream& osobject,const XYpoint&);
 friend istream& operator>>(istream& isobject, XYpoint&);
 
  private:
  int x;
  int y;
  public:
   XYpoint();
   XYpoint(int xx, int yy);
   void setPoints(int xx, int yy);
   void printpoints();
   bool operator<(const XYpoint&) const;
   bool operator>(const XYpoint&) const;
   bool operator<=(const XYpoint&) const;
   bool operator>=(const XYpoint&) const;
   bool operator==(const XYpoint&) const;
   bool operator!=(const XYpoint&) const;
   XYpoint operator+(const XYpoint&) const;
   void operator++();
   void operator++(int);
 
   
   
};
istream& operator>>(istream& isobject, XYpoint& p1){

isobject >> p1.x >> p1.y;
return isobject;


}
  ostream& operator<<(ostream& osobject, const XYpoint& p1){
   
   osobject << "x value: " << p1.x;
   osobject << "y value: "<< p1.y;
   return osobject;
  }

XYpoint::XYpoint(){
 x = 0;
 y = 0;
}
XYpoint::XYpoint(int xx, int yy){
setPoints(xx,yy);
}
void XYpoint::setPoints(int xx,int yy){
x = xx;
y = yy;
}
void XYpoint::operator++(){
x++;
y++;
}
void XYpoint::operator++(int){
++x;
++y;

}
XYpoint XYpoint::operator+(const XYpoint& p1) const{
XYpoint tempObj;
tempObj.x = x + p1.x;
tempObj.y = y + p1.y;
return tempObj;
}
bool XYpoint::operator<( const XYpoint& p1) const{
float d1 = sqrt(x * x + (y*y));
float d2 = sqrt(p1.x * p1.x + (p1.y * p1.y));
 return ( d1 < d2) ? 1 : 0;
}
 bool XYpoint::operator>( const XYpoint& p1) const{
  float d1 = sqrt(x * x + (y*y));
  float d2 = sqrt(p1.x * p1.x + (p1.y * p1.y));
   return ( d1 > d2) ? 1 : 0;
  }
  bool XYpoint::operator>=( const XYpoint& p1) const{
    float d1 = sqrt(x * x + (y*y));
    float d2 = sqrt(p1.x * p1.x + (p1.y * p1.y));
     return ( d1 >= d2) ? 1 : 0;
    }
  bool XYpoint::operator<=( const XYpoint& p1) const{
    float d1 = sqrt(x * x + (y*y));
    float d2 = sqrt(p1.x * p1.x + (p1.y * p1.y));
     return ( d1 <= d2) ? 1 : 0;
    }
 bool XYpoint::operator==( const XYpoint& p1) const{
  float d1 = sqrt(x * x + (y*y));
  float d2 = sqrt(p1.x * p1.x + (p1.y * p1.y));
   return ( d1 == d2) ? 1 : 0;
  }
 bool XYpoint::operator!=( const XYpoint& p1) const{
  float d1 = sqrt(x * x + (y*y));
  float d2 = sqrt(p1.x * p1.x + (p1.y * p1.y));
   return ( d1 != d2) ? 1 : 0;
  }


int main(){

XYpoint p1(2,3);
XYpoint p2(3,4);
XYpoint p8,p3;
if(p1 < p2)
cout << "< works: lesser true" <<endl;
else
cout << "< works: greaterthan true"<<endl;
if(p1 > p2)
cout << "> works: greaterthan true" <<endl;
else
cout << "> works: lesserthan true" <<endl;
if(p1 == p2)
cout << "== works: equal" << endl;
else
cout << "== works: not equal" << endl;

cout << p1 << endl;
cout << "Enter x and y value;"<<endl;
cin >> p8;
cout << p8;
 p3 = p1 + p2;
cout << p3 << endl;
++p3;
cout << p3 <<endl;
p3++;
cout << p3 <<endl;

return 0;
}

#include<iostream>
using namespace std;
template<class...> class weight;


template<class T>
class weight<T>{
	private:
		T kg;
	public:
		void setdata(T x){
			kg = x;
		}
		T getdata(){
                  return kg;
		}
};


int main(){

weight <int>obj1;
obj1.setdata(5);
cout << "value is: " << obj1.getdata() << endl;


return 0;
}

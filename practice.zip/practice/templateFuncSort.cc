#include<iostream>
using namespace std;
#include<vector>
#include<string>

template<typename T>
void sort(vector<T> v){
	for(int i =0 ; i < v.size(); i++){
		for( int j =0; j < (v.size()-i-1); j++){
			if(v[j] > v[j+1]){
                         T temp;
			 temp = v[j];
			 v[j] = v[j+1];
			 v[j+1] = temp;
                  	}
                        
		}
	}
	for(int i = 0; i < v.size(); i++){
        cout << v[i] << endl;
	}

}




int main(){
 vector<int> a = { 1, 2,6 ,8, 9,11, 0 ,-1};
 vector<float> b = { 4.5, 8.9 , 4.3, 4.4};
 vector<string> m = {"Z" , "m", "s"};
sort<int>(a);
sort<float>(b);
sort<string>(m);



return 0;
}

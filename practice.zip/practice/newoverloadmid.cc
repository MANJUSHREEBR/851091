#include<iostream>
using namespace std;

class rectangle{
        //overloading of insertion and extraction operators
	friend ostream& operator<<(ostream&,const rectangle&);
	friend istream& operator>>(istream&, rectangle&);
	private:
		int length;
		int width;
	public:
		void print(){
                      cout << "length: " << length << endl;
		      cout << "width: " << width << endl;
		};
                 rectangle(){
                    length = 0;
		     width = 0;

		 }
		 rectangle(int l, int w){
                  length = l;
		  width = w;
		 };

                 rectangle operator+(const rectangle& rect) const;
		 rectangle operator*(const rectangle& rect) const;
		 bool operator==(const rectangle& rect) const;
		 bool operator!=(const rectangle& rect)const;


};
rectangle rectangle::operator+(const rectangle& rect) const{
	rectangle temp;
	temp.length = length + rect.length;
	temp.width = width + rect.width;
return temp;

}
rectangle rectangle::operator*(const rectangle& rect) const{
        rectangle temp;
        temp.length = length * rect.length;
        temp.width = width * rect.width;
return temp;

}
bool rectangle::operator==(const rectangle& rect) const{
return ( length == rect.length && width == rect.width);


}
ostream& operator<<(ostream& osobject,const rectangle& rect){
	osobject << "Length :" << rect.length;
	osobject << "width :" << rect.width;
	return osobject;
}
istream& operator>>(istream& isobject,rectangle& rect){
        isobject  >> rect.length >> rect.width;
        return isobject;
}

int main(){
rectangle r1(1,3);
rectangle r2(1,3);
rectangle r3,r4;
rectangle newobj;
r3 = r1 + r2; 
r3.print();
r4 = r1 * r2;
r4.print();
r1.print();
r2.print();
if(r1 == r2 == true) {
cout << "equal:" << endl;
}
else 
cout << "not equal" << endl;
cout << r1 << endl;
cout << r2 <<endl;
cout<< "Enter the length and width of a rectangle" <<endl;
cin >> newobj;
cout << newobj;

return 0;
}

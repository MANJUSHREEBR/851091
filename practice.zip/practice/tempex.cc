#include<iostream>
using namespace std;

template<typename T>
T add(T x, T y){
 return(x + y);

}

int main(){
cout << "additon of two integers" << add<int>(3,4)  <<endl;
cout << "addition of float number"  << add<float>(3.3 , 4.5)  <<endl;

return 0;
}

#include<iostream>
using namespace std;

struct MyStruct{
int a;
int b ;
double c;
};

int main(){

MyStruct s;
s.a = 1;
s.b = 2;
s.c = 3;
 printf("s.a=%d\n", s.a);

    printf("s.b=%d\n", s.b);

    printf("s.c=%f\n", s.c);

    s = {0};

    printf("s.a=%d\n", s.a);

    printf("s.b=%d\n", s.b);

    printf("s.c=%f\n", s.c);


return 0;
}

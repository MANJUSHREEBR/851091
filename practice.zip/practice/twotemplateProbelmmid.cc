
#include<iostream>
using namespace std;
#include<string>



template<class...>class Pair;

//First class template
template<class T>
class Pair<T>{
public:
Pair(T f, T s);
T getFirst() const;
T getSecond() const;
void setFirst(T f);
void setSecond(T s);

private:
T first;
T second;
};
template<class T>
Pair<T>::Pair(T f, T s){
first = f;
second = s;
}

template<class T>
T Pair<T>::getFirst() const{

return first;

};
template<class T>
T Pair<T>::getSecond() const{
return second;

}
template<class T>
void Pair<T>::setFirst(T f){
first = f;
}
template<class T>
void Pair<T>::setSecond(T s){
second = s;
}
// second class template 
template<class T, class M>
class Pair<T,M>{
public:
Pair(T f, M s);
T getFirst() const;
M getSecond() const;
void setFirst(T f);
void setSecond(M s);

private:
T first;
M second;
};
template<class T, class M>
Pair<T, M>::Pair(T f, M s){
first = f;
second = s;
}

template<class T, class M>
T Pair<T, M>::getFirst() const{

return first;

};
template<class T, class M>
M Pair<T, M>::getSecond() const{
return second;

}
template<class T, class M>
void Pair<T, M>::setFirst(T f){
first = f;
}
template<class T,class M>
void Pair<T, M>::setSecond(M s){
second = s;
}


int main(){


Pair <int,int> p2(3,4);
cout << p2.getFirst() << endl;
cout << p2.getSecond() <<endl;
p2.setFirst(8);
p2.setSecond(9);
cout << p2.getFirst() << endl;
cout << p2.getSecond() <<endl;

Pair <int, string> p1(3,"manju");
cout << p1.getFirst() << endl;
cout << p1.getSecond() <<endl;
p1.setFirst(8);
p1.setSecond("raghu");
cout << p1.getFirst() << endl;
cout << p1.getSecond() <<endl;







return 0;
}

#include<iostream>
using namespace std;
class mybase{

	public:
		void show(){
			cout<< "Base class show function called;" << endl;
		}
		virtual void print(){
 			cout << "Baseclass print is called;" <<endl;
                }

};
class myderived : public mybase{

  public:
                void show(){
                        cout<< "derived class show function called;" << endl;
                }
                 void print(){
                        cout << "derived class print is called;" <<endl;
                }
};

int main(){

mybase *basep;
myderived derivedobj;

basep = &derivedobj;

basep -> print();
basep -> show();

return 0;
}




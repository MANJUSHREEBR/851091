#include<iostream>
using namespace std;
#include<string>

template<class elmType>
class arrayListType{

const arrayListType<elmType>& operator=(const arrayListType<elmType>&);

void print() const;
void insertAt(int location, const elmType& insertitem);
elmType getelm(int location) const;
arrayListType(int size = 10);

arrayListType(const arrayListType<elmType>& otherList);
~arrayListType();

private:
elmType *list;
int length;
int maxsize;
};

template<class elmType>
void arrayListType<elmType>::print() const
{
for(int i =0; i < length; i++)
cout <<list[i]<<endl;
}

template<class <elmType>
void arrayListType<elmType>::insertAt(int location, const elmType& insertItem){

if(location < 0 || location >= maxsize)
cerr << "position is out of range" << endl;
else if (length >= maxsize)
cerr << "cannot insert in a full list"<<endl;
else{
for(int i = length; i > location; i--)

list[i] = list[i-1];
list[location] = insertItem;
length ++;

}
}
template<class elmType>
arrayListType<elmType>::arrayListType(int size){

if(size < 0){
maxsize = 100;
}
else{
maxsize = 0;
}
length = 0;
list = new elmType[maxsize];
assert(list != NULL);
}

template<class elmType>
arrayListType<elmType>::~arrayListType(){
 delete [] list;

}
//copy constructor

template <class elmType>
arrayListType<elmType>::arrayListType(const arrayListType<elmType>& otherList)
{

maxsize = otherList.maxsize;
length = otherList.length;
list = new elmType[maxsize];
assert(list != NULL);

for(int j=0; j<length; j++)
list[j] = otherList.list[j];
}
//overload of assignment opeartaor
template<class elmType>
const arrayListType<elmType>& arrayListType<elmType>::operator=(const arrayListType<elmType>& otherList){

if(this != &otherList){
delete [] list;
maxsize = otherList.maxsize;
length = otherList.length;
list = new elmType[maxsize];
assert(list != NULL);
for(int i = 0; i< length;i++)
list[i] = otherList.list[i];
}

return *this;



}

int main(){

arrayListType<int> intList(50);





return 0;
}

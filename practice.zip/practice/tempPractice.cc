#ifndef CALL_TEMP_H
#define CALL_TEMP_H

#include <iostream>
#include<string>

template <typename...> class Foo;

template <typename A, typename B>
class Foo<A, B>
{
public:
    void output() {
        std::cout << a_ << b_ << '\n';
    }
    A a_;
    B b_;
};

template <typename A, typename B, typename C>
class Foo<A, B, C>
{
public:
    void output() {
        std::cout << a_ << b_ << c_ << '\n';
    }
    A a_;
    B b_;
    C c_;
};
int main()
{
    Foo<int ,int> doubleint;
    doubleint.a_ = 1;
    doubleint.b_ = 2;
    doubleint.output();
   Foo<int , int ,std::string> comp;
   comp.a_ = 1;
    comp.b_ = 2;
   comp.c_ = "haha";
  comp.output();
    return 0;
}
#endif

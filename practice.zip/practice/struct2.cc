#include<iostream>
using namespace std;


struct fatstruct{


char array[5000000];

};


void enumeratefs(const fatstruct &myfs){

for(int i = 0; i< 5000000; i++){

char c = myfs.array[i];
cout << int(c) << endl;

}
}

int main(){

fatstruct xfs;
for(int i = 0; i< 10000; i++)
	enumeratefs(xfs);


}



#include<iostream>
using namespace std;

void interleave(vector<string> &v){
for(int i =0 ; i< v.size() ; i++){
 for(int j = 



}




} 

int main(){
vector<string> v;
v = {"manju", "raghu" , "kavya"};
interleave(v);

return 0;
}

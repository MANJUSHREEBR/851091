#include<iostream>
using namespace std;
#include<string>
void checkanagram(string s1, string s2){
if( s1.size() == s2.size()){
 for(int i = 0; i < s1.size() -1; i++){
     for(int j = 0 ; j < (s1.size() - i -1); j++){
       if(s1[j] > s1[j+1]){
        char temp = s1[j];
            s1[j] = s1[j+1];
              s1[j+1] = temp;
         
        
        }

     if(s2[j] > s2[j+1]){
       char temp1 = s2[j];
         s2[j] = s2[j+1];
        s2[j+1] = temp1;


}
}
}
cout << s1 << endl;
cout << s2 << endl;
if(s1 == s2){
cout << "given strings are anagram";
}
else{
cout << "given strings are not anagram";
}
}
else
cout << "the given strings are not anagram";
}
int main(){
string s1 = "manju";
string s2 = "ujnma";
string s3 = "kavya";
string s4 = "kava";

checkanagram(s1, s2);
checkanagram(s3, s4);


return 0;
}

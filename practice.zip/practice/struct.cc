#include<iostream>
using namespace std;


struct Mystruct{
int a;
int b;
double c;

};

int main(){

Mystruct s;
s.a = 1;
s.b = 2;
s.c = 3;

cout << s.a << " " << s.b << " " << s.c;

s={0,};
cout << s.a << " " << s.b << " " << s.c;
return 0;
}









#include<iostream>
using namespace std;

class weight{
	private:
		int kg;
	public:
		weight(){kg = 0;};
		weight(int x){ kg =x;};
		void print(){ cout << "weight: " << kg << endl;
		}
               void operator ++(){
                 ++kg;
                    
	       }
	        void operator ++(int){
                 kg++;

               }

          
};

int main(){

	weight w1(8);
         ++w1;
	 w1.print();
	 w1++;
	 w1.print();

return 0;
}

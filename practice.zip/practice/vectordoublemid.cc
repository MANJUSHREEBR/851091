#include<iostream>
using namespace std;
#include<vector>

void doublefloat(vector<float> &v){

for(int i = 0; i < v.size(); i++){
 float temp = v.at(i) * v.at(i);
 v.at(i) = temp;
}

}
int main(){

vector<float> v = { 1.1 , 4.5, 8.9, 9.9, 7.6};
for(int i = 0; i < v.size(); i++){
 cout << v.at(i)<< endl;
 }
doublefloat(v);
for(int i = 0; i < v.size(); i++){
cout << v.at(i)<< endl;
}


return 0;
}

#include<iostream>
using namespace std;
//baseclass
class XYpoint{
public:

void setpoints(int xx, int yy);
int getx();
int gety();
XYpoint();
XYpoint(int xx, int yy);
void print();

private:
int x;
int y;

};
XYpoint::XYpoint(){
 x =0;
 y =0;
}
XYpoint::XYpoint(int xx, int yy){
x = xx;
y=yy;

}
void XYpoint::setpoints(int xx, int yy){
x = xx;
y =yy;
}
void XYpoint::print(){
cout << x << " " << y<<endl;
};
int XYpoint::getx(){
return x;
}
int XYpoint::gety(){
return y;
}
//derived class
class XYZpoint:public XYpoint{
public:
void setpoints(int xx, int yy, int zz);
int getx();
int gety();
int getz();
void print();
XYZpoint();
XYZpoint(int xx, int yy, int zz);


private:
int z;
};
void XYZpoint::print(){
XYpoint::print();
cout << z;
}
void XYZpoint::setpoints(int xx, int yy, int zz){

XYpoint::setpoints(xx, yy);
z = zz;
}
int XYZpoint::getx(){

return getx();

}
int XYZpoint::gety(){

return gety();
}
int XYZpoint::getz(){
return z;
}
XYZpoint::XYZpoint(){
z =0;
}
XYZpoint::XYZpoint(int xx, int yy, int zz)
         :XYpoint(xx, yy)
{
 z = zz;
}

int main(){
XYpoint p1(2,3);
XYZpoint p2(4,5,6);
p1.print();
cout <<endl;
p2.print();
cout << endl;
return 0;
}

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var app = angular.module('app', []);
app.controller('CarouselDemoCtrl', CarouselDemoCtrl);

function CarouselDemoCtrl($scope){
        $scope.displayImage=false;
	$scope.displayCarousel=true;
        $scope.slides=[
    {
      image: 'images/image1.jpg'

    },
    {
      image: 'images/image1.jpg'
    },
    {
      image: 'images/image1.jpg'
    },
    {
      image: 'images/image1.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image3.jpg'
    },
    {
      image: 'images/image3.jpg'
    }
    
    
     
    
   
   
   
    
  
    
     
   
   
   
];
if($scope.slides.length%4==0){
  $scope.getNumber = 4;  
}

else
 $scope.getNumber=$scope.slides.length%4;
 
 $scope.showDiv=function(imagePath){
         
	$scope.displayCarousel=false;
	$scope.imgShow=imagePath;
        $scope.displayImage=true;
  
  }
  
 
}
$('.carousel').carousel({
    
}).on('slid.bs.carousel', function () {
		curSlide = $('.active');
	  if(curSlide.is( ':first-child' )) {
		 $('.left').hide();
		 return;
	  } else {
		 $('.left').show();	  
	  }
	  if (curSlide.is( ':last-child' )) {
		 $('.right').hide();
		 return;
	  } else {
		 $('.right').show();	  
	  }
	});

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var app = angular.module('app');
app.filter('app', function() {

  // Create the return function and set the required parameter as well as an optional paramater
  return function(input, number) {

   return input;

  }

});
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('selectorDiv', function() {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
               scope.numbers=[];
               scope.existingNumber= 0;
               //scope.temp=scope.existingNumber;
               for(i=1;i<=80;i++){
                scope.numbers.push(i);
               }
              
              scope.change=function(){
                    scope.numbers=[];
                    //scope.firstDiv=[];
                   scope.existingNumber = parseInt(scope.selectedNumber)+ scope.existingNumber;
                   alert(scope.existingNumber);
                    
                   for(i=1;i<=scope.selectedNumber;i++){
                    scope.slotNumbers.push(i);
                   }
                   if(scope.existingNumber<=20){
                     
                      scope.div4= scope.slotNumbers;
                      alert(scope.div4);
                   }
                   
                   
                   for(i=1;i<=80-parseInt(scope.existingNumber);i++){
                      scope.numbers.push(i);
                   }
                   
                  }
              
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',

   //template to be rendered by the directive.
  template: '<div class="col-sm-1"></div><div class="col-sm-6"><input type=color ng-model="slotColor"><select ng-model="selectedNumber"><option ng-repeat="x in numbers track by $index">{{x}}</option>' + 
            '</select><button class="btn btn-info" ng-click="change()">Add</button></div>'
        }
        
    }); 
      
 




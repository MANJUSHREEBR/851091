/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('popupSlot', function() {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
         
                
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',
 scope:{
   slotNum:'='  
 },
   //template to be rendered by the directive.
  template: '<div ng-repeat="x in slotNum by $index" id="popoverBlocks">'
        }
        
    }); 
      
 

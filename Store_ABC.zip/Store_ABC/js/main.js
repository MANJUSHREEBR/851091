var app = angular.module("Store_ABC",["ngRoute"]);
			app.config(function($routeProvider){
					$routeProvider
					.when('/home',{
						templateUrl : 'views/storeView.html',
						controller :  'storeViewCtrl'
					})
					.when('/cart',{
						templateUrl : 'views/viewCart.html',
						controller : 'viewCartCtrl'
					})
				});
				app.controller('storeViewCtrl',function($scope,$http){
					$http.get('window.location.protocol + ‘//’ + products.json').success(function(data){
						$scope.products = data;
					});
					});
					app.controller('viewCartCtrl',function($scope,$http){
					$scope.welcome="welcome to bnglr";
				   });
			
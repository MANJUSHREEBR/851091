(function(){
	'use strict' ;
	
	angular
	.module('MakeMyTrip')
	.controller("loadCtrl",loadCtrl);
	
	
	loadCtrl.$inject=['$scope','$http','$rootScope','$location'];
	function loadCtrl($scope,$http,$rootScope, $location){
		
		 
		
		
		console.log($rootScope.count);
		if(typeof $rootScope.count == 'undefined')
		{
			$location.path( "/login" );		    
		} 
		else{
			
		
		$(".nav a").on("click", function(){
		   $(".nav").find(".active").removeClass("active");
		   $(this).parent().addClass("active");
		});	
		
		
		$scope.submitted=false;
		$scope.time=time;
		$scope.to="";
		$scope.load=load;
		
		$scope.addZero=addZero;
		$scope.details=["Bangalore","Mumbai","Chennai","Delhi"];
		$scope.AirLines=["Air India","Spice Jet","Indigo","Jet Airways"];
		var date1=new Date();
			$scope.travelDate=date1.getFullYear() + '-' + ('0' + (date1.getMonth() + 1)).slice(-2) + '-' + ('0' + (date1.getDate())).slice(-2) ;
			$scope.endDate=(date1.getFullYear()+1) + '-' + ('0' + (date1.getMonth() + 1)).slice(-2) + '-' + ('0' + (date1.getDate())).slice(-2) ;
			
		$scope.variab = true;
		
		
		$scope.update = function() {
			var i=0;
			console.log($scope.from1 );	
			$scope.toAdresses=["Bangalore","Mumbai","Chennai","Delhi"];	
			$scope.variab = false;
			
			for( i= $scope.toAdresses.length - 1; i >= 0; i--)
				{
					if( $scope.toAdresses[i] == $scope.from1)
						$scope.toAdresses.splice(i,1);
				}			  
			   console.log($scope.toAdresses);
		   }
		
		function time(){
			
			
			var time=new Date($scope.arrival);
		
					var h=$scope.addZero(time.getHours());
					var m=$scope.addZero(time.getMinutes());
				 
					
					var time1=new Date($scope.departure);
					var h1=$scope.addZero(time1.getHours());
					var m1=$scope.addZero(time1.getMinutes());
				    
					var h2;
					var m2;
					
					if(m<m1)
					{
						m=m+60;
						m2=m-m1;
						h2=h-h1-1;
						if(h2<0)
							h2=-h2;
					}
					else{
						m2=m-m1;
						h2=h-h1;
						if(h2<0)
							h2=-h2;
					}
					
					
					
				  $scope.duration = $scope.addZero(h2) + "h:" + $scope.addZero(m2) + "m"; 
			
		}
		
		
		function load(){
			if($scope.from1==$scope.to)
		 {
				toastr.error("Arrival and Departure cann't be same");
		 }
			  else  
			  {       
		
					var data={};
					data['from1']=$scope.from1;
				    data['to']=$scope.to;
				
					var d=$scope.date.toString();
				
					data['date']=d.substr(4, 11);					
					var time=new Date($scope.arrival);
					var h=$scope.addZero(time.getHours());
					var m=$scope.addZero(time.getMinutes());
				    var t= h + ":" + m;
					data['arrival']=t;
					
					var time1=new Date($scope.departure);
					var h1=$scope.addZero(time1.getHours());
					var m1=$scope.addZero(time1.getMinutes());
				    var t1= h1 + ":" + m1;
					
					if(t<t1){
						console.log(t);
						toastr.error('arrival time cannot be less than departure time');
						return false;
						
					}
					else{
						data['departure']=t1;
						
					}
					data['duration']=$scope.duration;
					data['airline']=$scope.airline;
					data['price']=$scope.price;
					console.log(JSON.stringify(data));					
					
					$scope.submitted=true;	
          					
					
					$http({
						method:'POST',
						url:'/Detail',
						data:JSON.stringify(data)
					}).
					success(function (response){				
						console.log(data);											
						
					});	
				  
                   $scope.from1="";
				   $scope.to="";
				   $scope.arrival="";
				   $scope.departure="";
				   $scope.duration="";
				   $scope.airline="";
				   $scope.price="";	
				   $scope.date= "";			   
				   toastr.success('Flight Details loaded successfully!');					
			}
		}
			
	 function addZero(i){
		 if(i < 10){
			 i="0" + i;
			 }
		 return i;		 
	 }
	 
	}
}
	
})();
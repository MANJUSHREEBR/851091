angular.module('myApp')
.directive('colorDiv', function(clrdataFactory) {
       return {
      //link function to add behavior to the dom.
      link:function(scope){
                scope.changeClr=function(clr1,clr2){
                clrdataFactory.div1clr=clr2;
                clrdataFactory.div2clr=clr1;
                scope.changeColor();
                
                  }
            },
      //invoking the directive as an element by setting restrict property to 'E'.
      restrict: 'E',
      //creating an isolated scope for the directive.
       scope:{
           showTxtfield:'=',
           showClrfield:'=',
           modelValue:'=',
           changeColor:'&'
         },
      //template to be rendered by the directive.
       template: '<div class="col-sm-6" style="background-color:{{modelValue}}">'+
     ' <input type="text" placeholder="Enter hex color" ng-model="backgrnd1" ng-show="showTxtfield"><input type="color" ng-show="showClrfield" ng-model="backgrnd2" >'+
      '<input type="button" class="btn btn-primary" ng-click="changeClr(backgrnd1,backgrnd2)" value="changeColor"></div>'
        }
        
    })


   
    
      
 
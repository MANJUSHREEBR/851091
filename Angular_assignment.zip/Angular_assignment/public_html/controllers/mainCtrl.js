angular.module('myApp')
.controller("mainCtrl", function($scope,colorFactory,clrdataFactory){
      //Intialising initial background colors
         $scope.bgClr="#0000FF";
         $scope.bgClr1="#FFA500";
         $scope.bgClr2="pink";
       //function to change the div2 background. 
         $scope.change1=function(){
          $scope.bgClr1=clrdataFactory.div2clr;
         }
        //function to change div1 background.
         $scope.change2=function(){
           $scope.bgClr=clrdataFactory.div1clr;
         }
         //function to merge two colors.
          $scope.change3=function(){
          $scope.bgClr2 = colorFactory.mergeColor($scope.bgClr,$scope.bgClr1);
         }
 });
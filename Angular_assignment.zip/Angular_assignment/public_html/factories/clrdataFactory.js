
//Factory to communicate between the directives.
angular.module('myApp')
.factory('clrdataFactory', function(){
    return {
     selectedColors:{}
     }               
});
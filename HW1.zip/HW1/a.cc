/*
 * a.cc
 *
 *  Created on: Feb 15, 2021
 *      Author: manju_br
 */


#include "a.h"
using namespace std;

void CMPE180ASort(int a[] , int sz)
{
     int temp;
     for (int i=0; i<(sz -1); i++)
    {
          for(int j = (i+1); j < sz; j++)
         {
                if (a[i] > a[j])
               {
                        temp= a[i];
                        a[i] = a[j];
                        a[j] = temp;
               }
          }
     }
     for(int i=0; i< sz; i++){
     				cout << a[i]<<" ";
     	 }
}

void CMPE180ASort(char a[] , int sz)
{

     char temp;
     for (int i=0; i<(sz -1); i++)
    {
          for(int j = (i+1); j < sz; j++)
         {
                if (a[i] > a[j])
               {
                        temp= a[i];
                        a[i] = a[j];
                        a[j] = temp;
               }
          }
     }
     for(int i=0; i < sz; i++){
     				cout << a[i]<<" ";
     	 }

}
int main() {
   char a[] = {'b','a', 'A', 'B'};
  int n = sizeof(a)/ sizeof(a[0]);
   int i;
   cout<<"Given array is:"<<endl;
   for (i = 0; i < 1; i++)
   cout<< a[i] <<" ";
   cout<<endl;
   CMPE180ASort(a, n);
      return 0;
}

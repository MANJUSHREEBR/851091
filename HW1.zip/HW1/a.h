/*
 * a.h
 *
 *  Created on: Feb 15, 2021
 *      Author: manju_br
 */



#include<iostream>




void cmpe180ASort(int a[], int sz);

void cmpe180ASort(char c[], int sz);

/*
 * main.cpp
 *
 *  Created on: Feb 16, 2021
 *      Author: manju_br
 */




#include "a.h"

int main() {
  int a[] = {4,66,-9,80};
  int n = sizeof(a)/ sizeof(a[0]);
   int i;
   cout<<"Given array is:"<<endl;
   for (i = 0; i < n; i++)
   cout<< a[i] <<" \t";
   cout<<endl;
   cmpe180ASort(a, n);
      return 0;
}

/*
 * a.cc
 *
 *  Created on: Feb 15, 2021
 *      Author: manju_br
 */


#include "a.h"


void cmpe180ASort(int a[] , int sz)
{
     int temp;
     for (int i=0; i<(sz - 1); i++)
    {
          for(int j = (i+1); j < sz; j++)
         {
                if (a[i] > a[j])
               {
                        temp= a[i];
                        a[i] = a[j];
                        a[j] = temp;
               }
          }
     }
     cout<<"Sorted integer array is:"<<endl;
     for(int i=0; i< sz; i++){
     				cout << a[i]<<"\t";
     	 }
}

void cmpe180ASort(char a[] , int sz)
{

     int temp;
     for (int i=0; i<(sz - 1); i++)
    {
          for(int j = (i+1); j < sz; j++)
         {
                if (a[i] > a[j])
               {
                        temp= a[i];
                        a[i] = a[j];
                        a[j] = temp;
               }
          }
     }
     cout<<"Sorted character array is:"<<endl;
     for(int i=0; i < sz; i++){
     				cout << a[i]<<"\t ";
     	 }

}


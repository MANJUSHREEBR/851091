/*
 * a.h
 *
 *  Created on: Feb 15, 2021
 *      Author: Manjushree Berike Rajanna 
        SID: 015275377
 */


#ifndef CMPE180ASORT_H
#define CMPE180ASORT_H

//#include <iostream>
//using namespace std;


void cmpe180ASort(int a[], int sz);
void cmpe180ASort(char c[], int sz);


#endif

#include "cmpe180ASort-1.h"
//#include<iostream>

//using namespace std;

int main() {
  int a[] ={3,4,-8,-9};
  int n = sizeof(a)/ sizeof(a[0]);
   int i;
  cout<<"Given array is:\n";
   for (i = 0; i < n; i++)
  cout<< a[i] <<" \t";
   cout<<endl;
   cmpe180ASort(a, n);
   cout<<"Sorted integer array is:"<<endl;
     for(int i=0; i< n; i++){
       cout << a[i]<<"\t";
         }
cout<<endl;
      return 0;
}

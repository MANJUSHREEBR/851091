/*
 * cmpe180ASort.cc
 *
 *  Created on: Feb 15, 2021
 *      Author: Manjushree Berike Rajanna
 *      SID: 015275377 
 */
#include<iostream>
using namespace std;

#include "cmpe180ASort-1.h"


void cmpe180ASort(int a[] , int sz)  //Exchange sort function 
{
     int temp;
     for (int i=0; i<(sz - 1); i++)
    {
          for(int j = (i+1); j < sz; j++)
         {
                if (a[i] > a[j])
               {
                        temp= a[i];
                        a[i] = a[j];
                        a[j] = temp;
               }
          }
     }
 
}

void cmpe180ASort(char a[] , int sz)   
{
	char temp;
     	for (int i=0; i<(sz - 1); i++)
    	{
        	for(int j = (i+1); j < sz; j++)
         	{
                	if (a[i] > a[j])
               		{
                        	temp= a[i];
                        	a[i] = a[j];
                        	a[j] = temp;
               		}
          	}
     	}
}


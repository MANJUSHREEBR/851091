#include "XYPoint.h"

float distance(XYPoint p1, XYPoint p2){
 return sqrt(pow(p2.x - p1.x, 2) +  
                pow(p2.y - p1.y, 2) * 1.0); 
 
}

float distance(XYPoint p1, XYPoint p2, XYPoint p3){

  return (distance( p1, p2) + distance(p2, p3)); 
}

float distance(XYPoint p1, XYPoint p2, XYPoint p3,XYPoint p4){
return (distance(p1, p2) + distance(p2, p3) + distance(p3, p4) );

}

float distance(XYPoint p1, XYPoint p2, XYPoint p3,XYPoint p4, XYPoint p5){
return (distance(p1, p2) + distance(p2, p3) + distance(p3,p4) + distance(p4,p5));
}

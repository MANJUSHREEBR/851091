#include<iostream>
using namespace std;

#include "XYPoint.h"

int main(){

XYPoint p1(-1,-1);
XYPoint p2(0,0);
XYPoint p3(-1,-1);
XYPoint p4(0,0);
XYPoint p5(-1,-1);

cout << "\n Distance between two points is: ";
cout << distance(p1, p2) <<endl;
cout << distance(p1, p2, p3) <<endl;
cout << distance(p1, p2, p3, p4) <<endl;
cout << distance(p1, p2, p3, p4, p5) <<endl;









return 0;
}

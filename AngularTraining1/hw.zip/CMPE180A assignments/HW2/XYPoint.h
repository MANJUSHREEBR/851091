/*
 * XYPoint.h
 *
 *  Created on: Feb 19 , 2021
 *      Author: Manjushree Berike Rajanna 
        SID: 015275377
 */


#ifndef XYPOINT_H
#define XYPOINT_H

#include<cmath>


class XYPoint {

public:

int x;

int y;


XYPoint(int xc, int yc) : x(xc), y(yc) {}

};


float distance(XYPoint p1, XYPoint p2); 
float distance(XYPoint p1, XYPoint p2, XYPoint p3);
float distance(XYPoint p1, XYPoint p2, XYPoint p3, XYPoint p4);
float distance(XYPoint p1, XYPoint p2, XYPoint p3, XYPoint p4, XYPoint p5);




#endif

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('slotDiv', function() {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
            scope.a=[];
                    
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',

   //template to be rendered by the directive.
  template: '<div class="row"><div class="col-sm-12"><button ng-repeat="x in a" id="slots"></button>' + 
            '</div></div>'
        }
        
    }); 
      
 

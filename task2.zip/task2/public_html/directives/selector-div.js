/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('selectorDiv', function(dataStore) {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
               scope.numbers=[];
               scope.existingNumber= 0;
               //scope.temp=scope.existingNumber;
               for(i=1;i<=80;i++){
                scope.numbers.push(i);
               }
              
              scope.change=function(){
                    scope.numbers=[];
                    scope.div1=dataStore.div1;
                    scope.div2=dataStore.div2;
                    scope.div3=dataStore.div3;
                    scope.div4=dataStore.div4;
                    alert(scope.div1);
                   scope.existingNumber = parseInt(scope.selectedNumber)+ scope.existingNumber;
                   alert(scope.existingNumber);
                    
                   for(i=1;i<=scope.selectedNumber;i++){
                    scope.slotNumbers.push(i);
                   }
                   if(scope.div1.length<=20){

                      for(i=1;i<=parseInt(scope.existingNumber);i++){

                         scope.div1.push(i);
                    }
                    dataStore.div1=scope.div1;
                    }
                   
                   if(scope.div2.length>20 && scope.div2.length<=40){

                      for(i=21;i<=parseInt(scope.existingNumber);i++){

                         scope.div2.push(i);
                    }
                   dataStore.div2=scope.div2;

                    }
                    if(scope.div3.length>40 && scope.div3.length<=60){

                      for(i=41;i<=parseInt(scope.existingNumber);i++){

                         scope.div3.push(i);
                    }
                   dataStore.div3=scope.div3;

                    }
                    if(scope.div4.length>60){

                      for(i=61;i<=parseInt(scope.existingNumber);i++){

                         scope.div4.push(i);
                    }
                    dataStore.div4=scope.div4;
                    }
                   
                   
                   
                   for(i=1;i<=80-parseInt(scope.existingNumber);i++){
                      scope.numbers.push(i);
                   }
                   
                  }
              
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',

   //template to be rendered by the directive.
  template: '<div class="col-sm-1"></div><div class="col-sm-6"><input type=color ng-model="slotColor"><select ng-model="selectedNumber"><option ng-repeat="x in numbers track by $index">{{x}}</option>' + 
            '</select><button class="btn btn-info" ng-click="change()">Add</button></div>'
        }
        
    }); 
      
 




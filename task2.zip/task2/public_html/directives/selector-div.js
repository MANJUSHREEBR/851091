/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('selectorDiv', function() {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
               scope.names=[];
               for(i=scope.a.length;i<=80;i++){
                      scope.names.push(i);
                  }
             
              scope.change=function(){
                   scope.a=[];
                  for(i=1;i<=scope.selectedName;i++){
                      scope.a.push(i);
                  }
                  
              }
              
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',

   //template to be rendered by the directive.
  template: '<div class="col-sm-1"></div><div class="col-sm-6"><select ng-model="selectedName" ng-change="change()"><option ng-repeat="x in names">{{x}}</option>' + 
            '</select><button class="btn btn-info">Add</button></div>'
        }
        
    }); 
      
 




/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('selectorDiv', function($localStorage) {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
               
            scope.flag=0;
            $localStorage.details=[];
            scope.numbers=[];
            scope.existingNumber= 0;
               //scope.temp=scope.existingNumber;
               for(i=1;i<=80;i++){
                scope.numbers.push(i);
               }
              
              scope.change=function(){
                    scope.dataValue=$localStorage.details;
                    scope.enteredDetails={color:"",name:"",number:""};
                    scope.enteredDetails.color=scope.slotColor;
                    scope.enteredDetails.name=scope.slotName;
                    scope.enteredDetails.number=scope.selectedNumber;
                    scope.dataValue.push(scope.enteredDetails);
                    $localStorage.details=scope.dataValue;
                    console.log(scope.dataValue);
                    console.log($localStorage.details);

                    scope.numbers=[];
                    scope.div1=[];
                    scope.div2=[];
                    scope.div3=[];
                    scope.div4=[];
                   
                   scope.existingNumber = parseInt(scope.selectedNumber)+ scope.existingNumber;
                     alert(scope.existingNumber);
                    
                   for(i=1;i<=scope.selectedNumber;i++){
                    scope.slotNumbers.push(i);
                   }
                   if(scope.existingNumber<=20){

                      for(i=1;i<=parseInt(scope.existingNumber);i++){
                         
                         scope.div1.push(i);
                    }
                  
                    }
                   
                   if(scope.existingNumber>20 && scope.existingNumber<=40){
                       for(i=1;i<=20;i++){

                         scope.div1.push(i);
                     }

                      for(i=21;i<=parseInt(scope.existingNumber);i++){

                         scope.div2.push(i);
                    }
                  

                    }
                    if(scope.existingNumber>40 && scope.existingNumber<=60){
                        for(i=1;i<=20;i++){

                         scope.div1.push(i);
                     }

                      for(i=21;i<=40;i++){

                         scope.div2.push(i);
                    }
                      for(i=41;i<=parseInt(scope.existingNumber);i++){

                         scope.div3.push(i);
                    }
                   

                    }
                    if(scope.existingNumber>60){

                      for(i=1;i<=20;i++){

                         scope.div1.push(i);
                     }

                      for(i=21;i<=40;i++){

                         scope.div2.push(i);
                    }
                      for(i=41;i<=60;i++){

                         scope.div3.push(i);
                    }
                      
                      
                      for(i=61;i<=parseInt(scope.existingNumber);i++){

                         scope.div4.push(i);
                    }
                   
                    }
                   
                   
                   
                   for(i=1;i<=80-parseInt(scope.existingNumber);i++){
                      scope.numbers.push(i);
                   }
                   
                  }
              
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',

   //template to be rendered by the directive.
  template: '<div class="col-sm-1"></div><div class="col-sm-6"><input type=color ng-model="slotColor"><input type="text" ng-model="slotName"><select ng-model="selectedNumber"><option ng-repeat="x in numbers track by $index">{{x}}</option>' + 
            '</select><button class="btn btn-info" ng-click="change()">Add</button></div>'
        }
        
    }); 
      
 




/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('popupSlot', function() {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
              
            console.log(scope.objValue[0].number);
          console.log(scope.objValue);
          
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',
 scope:{
   slotNum:'=' ,
   colorValue:'=',
   objValue:'='
 },
   //template to be rendered by the directive.
  template: '<div ng-repeat="x in slotNum track by $index"><div ng-repeat="y in objValue"><div ng-repeat="z in [1,2]" id="popoverBlocks" style="background-color:{{y.color}}"></div></div></div>'
        }
        
    }); 
      
 

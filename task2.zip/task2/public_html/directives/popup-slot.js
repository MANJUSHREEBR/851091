/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('popupSlot', function(dataStore) {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
              
       scope.remove=function(index){
           scope.slotNum.splice(index,1);
        }
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',
 scope:{
   slotNum:'=' ,
  
 },
   //template to be rendered by the directive.

  template: '<div ng-repeat="x in slotNum"><div ng-click="remove($index)" style="background-color:{{x.color}};width:{{x.number}};height:50px;float:left;color:white;text-align:center;">{{x.name}}</div>' +
            '</div></div>'
        }
        
    }); 
      
 

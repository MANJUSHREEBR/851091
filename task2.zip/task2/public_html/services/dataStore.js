var app = angular.module('myApp')
.service('dataStore', function () {
    this.div1 =[];
    this.div2=[];
    this.div3=[];
    this.div4=[]; 
    this.div1Width=0;
    this.div2Width=0;
    this.div3Width=0;
    this.div4Width=0;
    this.dataValues=function(slotColor,slotName,selectedNumber){
    	
    	 this.enteredDetails={color:"",name:"",number:""};
         this.enteredDetails.color=slotColor;
         this.enteredDetails.name=slotName;
         this.enteredDetails.number=((selectedNumber/20)*100)+"%";
      
         if(this.div1Width<100 && this.div2Width==0 && this.div3Width==0 && this.div4Width==0  ){
          this.temp=this.div1Width;
          this.div1Width += parseInt(this.enteredDetails.number);
          if(this.div1Width>100){
                    this.num=((100)-(this.temp))+"%";
                    this.div1.push({"color":slotColor,"name":slotName,"number":this.num});
                    this.enteredDetails.number=((this.div1Width)-(100))+"%";
                    this.div2Width += ((this.div1Width)-(100)) ;
                    console.log(this.div2Width);
                    if(this.div2Width>100){
                    this.div2.push({"color":slotColor,"name":slotName,"number":"100%"});
                     this.div3Width=(this.div2Width)-100;
                     if(this.div3Width>100){
                        this.div3.push({"color":slotColor,"name":slotName,"number":"100%"});
                        this.div4Width=(this.div3Width)-100;
                        this.div4.push({"color":slotColor,"name":slotName,"number":this.div4Width+"%"});

                        this.div3Width=100;
                       }
                      else{
                     this.div3.push({"color":slotColor,"name":slotName,"number":this.div3Width+"%"});
                        }
                     this.div2Width=100;
                  
                       
                    }
                    else{
                   this.div2.push(this.enteredDetails);}
               
                    this.div1Width=100;
    
                  }
                 else if(this.div1Width<=100){
                  this.div1.push(this.enteredDetails);

                  }
                 
                   }
                  else if(this.div1Width==100 && this.div2Width<100 && this.div3Width==0 && this.div4Width==0){
                     this.temp=this.div2Width;
                    this.div2Width += parseInt(this.enteredDetails.number);
                    if(this.div2Width>100){
                    this.num2=((100)-(this.temp))+"%";
                   // console.log(this.num2);
                    this.div2.push({"color":slotColor,"name":slotName,"number":this.num2});
                    this.enteredDetails.number=((this.div2Width)-(100))+"%";
                    this.div3Width += ((this.div2Width)-(100)) ;
                    if(this.div3Width>100){
                    this.div3.push({"color":slotColor,"name":slotName,"number":"100%"});
                    this.div4Width=(this.div3Width)-100;
                     if(this.div4Width>100){
                        this.div4.push({"color":slotColor,"name":slotName,"number":"100%"});
                        this.div4Width=100;
                       }
                     else{
                     this.div4.push({"color":slotColor,"name":slotName,"number":this.div4Width+"%"});
                        }
                     this.div3Width=100;
                  
                       
                    }
                    
                    


                    else{
                    this.div3.push(this.enteredDetails);
                  
                    this.div2Width=100;
                  }
    
                  }
                 else if(this.div2Width<=100){
                  this.div2.push(this.enteredDetails);
                  

                  }
                                   }
                 
            
                 
                   

                  else if(this.div1Width==100 && this.div2Width==100 && this.div3Width<100 && this.div4Width==0){
                    this.temp=this.div3Width;
                    this.div3Width += parseInt(this.enteredDetails.number);
                 if(this.div3Width>100){
                    this.num3=((100)-(this.temp))+"%";
                    this.div3.push({"color":slotColor,"name":slotName,"number":this.num3});
                    this.enteredDetails.number=((this.div3Width)-(100))+"%";
                    this.div4Width += ((this.div3Width)-(100)) ;
                    this.div4.push(this.enteredDetails);
                    this.div3Width=100;
    
                  }
                 else if(this.div3Width<=100){
                  this.div3.push(this.enteredDetails);
               

                  }
                   }
                  else if(this.div3Width==100 && this.div4Width<=100){
                   this.div4Width += parseInt(this.enteredDetails.number);
                   this.div4.push(this.enteredDetails);
                  
                       
                   }
                  else{
                  // this.div4Width += parseInt(this.enteredDetails.number);
                   this.div4.push(this.enteredDetails);
                   

                  }
               



    }

             

});
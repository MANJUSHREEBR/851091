var app = angular.module('myApp')
.service('dataStore', function () {
    this.div1 =[];
    this.div2=[];
    this.div3=[];
    this.div4=[]; 

});
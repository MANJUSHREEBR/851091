/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular.module('myApp')
.directive('selectorDiv', function($localStorage,dataStore) {
       return {
 //link function to add behavior to the dom.
  link: function(scope, element, attrs) {
              scope.removeAll=function(){
                  scope.width="0%";
                  scope.existingNumber= dataStore.existingNumber;;
                  dataStore.div1=[];
                  dataStore.div2=[];
                  dataStore.div3=[];
                  dataStore.div4=[];
                  scope.numbers=[];
                  dataStore.div1Width=0;
                  dataStore.div2Width=0;
                  dataStore.div3Width=0;
                  dataStore.div4Width=0;
                  for(i=1;i<=80;i++){
                  scope.numbers.push(i);
                  }
              
              }
             
             scope.numbers=[];
             scope.existingNumber= 0;
             scope.width="0%";
            
              for(i=1;i<=80-parseInt(scope.existingNumber);i++){
                scope.numbers.push(i);
               }
              
              scope.change=function(){
                   scope.popupOpen=true;
                   scope.numbers=[];
                   dataStore.existingNumber = parseInt(scope.selectedNumber)+ scope.existingNumber;
                   scope.existingNumber =dataStore.existingNumber;
                   scope.width=((parseInt(scope.existingNumber)/80)*100)+"%";

                   alert(scope.existingNumber);
                   for(i=1;i<=80-parseInt(scope.existingNumber);i++){
                      scope.numbers.push(i);
                   }
                   

                   dataStore.dataValues(scope.slotColor,scope.slotName,scope.selectedNumber);
                
                                
                    

                   //  scope.numbers=[];
                   scope.div1=dataStore.div1;
                   scope.div2=dataStore.div2;
                   scope.div3=dataStore.div3;
                   scope.div4=dataStore.div4;

                    
                  }
              
            },
 //invoking the directive as an element by setting restrict property to 'E'.
  restrict: 'AE',

   //template to be rendered by the directive.
  template: '<div class="col-sm-1"></div><div class="col-sm-6"><input type=color ng-model="slotColor"><input type="text" ng-model="slotName"><select ng-model="selectedNumber"><option ng-repeat="x in numbers track by $index">{{x}}</option>' + 
            '</select><button class="btn btn-info" ng-click="change()">Add</button ><button class="btn btn-info" ng-click="removeAll()">Remove All</button></div>'
        }
        
    }); 
      
 




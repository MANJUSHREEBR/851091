/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var app = angular.module('app', []);
app.controller('CarouselDemoCtrl', CarouselDemoCtrl);

function CarouselDemoCtrl($scope){
	
	$scope.myInterval = 3000;
	$scope.noWrapSlides = false;
	$scope.activeSlide = 0;
	$scope.displayImage=false;
	$scope.displayCarousel=true;
  $scope.slides=[
    {
      image: 'images/image1.jpg'

    },
    {
      image: 'images/image1.jpg'
    },
    {
      image: 'images/image1.jpg'
    },
    {
      image: 'images/image1.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image3.jpg'
    },
    {
      image: 'images/image2.jpg'
    }
    
  ];


$scope.getSlides=function(){
     var temp=[];
     if($scope.slides.length%4==0)
     temp= $scope.slides;
     if($scope.slides.length%4==1){
      temp=$scope.slides;
      var a =temp.pop($scope.slides.length);
      var length=temp.length;
      temp.push($scope.slides[length-3]);
      temp.push($scope.slides[length-2]);
      temp.push($scope.slides[length-1]);
      temp.push(a);
      }
    if($scope.slides.length%4==2){
      temp=$scope.slides;
      var a=[];
      a.push(temp.pop());
      a.push(temp.pop());
      var length=temp.length;
      temp.push($scope.slides[length-2]);
      temp.push($scope.slides[length-1]);
      temp.push(a[0]);
      temp.push(a[1]);
      }
      if($scope.slides.length%4==3){
      temp=$scope.slides;
      var a=[];
      a.push(temp.pop());
      a.push(temp.pop());
      a.push(temp.pop());

      var length=temp.length;
      temp.push($scope.slides[length-1]);
      temp.push(a[0]);
      temp.push(a[1]);
      temp.push(a[2]);

      }
    return temp;

}
// function getSlideNumber(number){
//         temp=$scope.slides;
//          var a=[];
//          for(i=1;i<=number;i++){
//           temp.pop();
//          }
//         var length=temp.length;
//           if(number==1){

//           }
//           if(number=z)
//          for(i=0;i<number;i++){
//           temp.push(a[0]);
//          }
// }

$scope.getNumber=function(){
    var temp=[];
   for(i=0;i<($scope.slides.length-4)/4;i++){
      temp.push(i); 
   }
   return temp;
}

 
 $scope.showDiv=function(imagePath){
         
	$scope.displayCarousel=false;
	$scope.imgShow=imagePath;
        $scope.displayImage=true;
  
  }
  
 
}

$('.carousel').carousel({
    
}).on('slid.bs.carousel', function () {
    curSlide = $('.active');
    if(curSlide.is( ':first-child' )) {
     $('.left').hide();
     $('.right').show();    

     return;
    } else {
     $('.left').show();   
    }
    if (curSlide.is( ':last-child' )) {
     $('.right').hide();
     return;
    } else {
     $('.right').show();    
    }
  });


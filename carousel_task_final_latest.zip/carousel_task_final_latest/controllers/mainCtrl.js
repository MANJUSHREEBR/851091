/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var app = angular.module('app', []);
app.controller('CarouselDemoCtrl', CarouselDemoCtrl);

function CarouselDemoCtrl($scope){
	$scope.displayImage=false;
	$scope.displayCarousel=true;
        $scope.slides=[
    {
      image: 'images/image1.jpg'

    },
    {
      image: 'images/image2.jpg'
    },
    {
      image: 'images/image3.jpg'
    },
    {
      image: 'images/image4.jpg'
    },
    {
      image: 'images/image5.jpg'
    },
    {
      image: 'images/image6.jpg'
    },
    {
      image: 'images/image7.jpg'
    },
    {
      image: 'images/image8.jpg'
    },
    {
      image: 'images/image9.jpg'
    },
    {
      image: 'images/image10.jpg'
    },
    {
      image: 'images/image10.jpg'
    }
    
   
  ];
  
 if($scope.slides.length%4==1)
      $scope.slides.splice($scope.slides.length-1,0,$scope.slides[$scope.slides.length-4],$scope.slides[$scope.slides.length-3],$scope.slides[$scope.slides.length-2]);
 if($scope.slides.length%4==2)
      $scope.slides.splice($scope.slides.length-2,0,$scope.slides[$scope.slides.length-4],$scope.slides[$scope.slides.length-3]);
 if($scope.slides.length%4==3)
      $scope.slides.splice($scope.slides.length-3,0,$scope.slides[$scope.slides.length-4]);
  

$scope.getNumber=function(){
    var temp=[];
    for(i=0;i<($scope.slides.length-4)/4;i++){
      temp.push(i); 
    }
   return temp;
}

 $scope.showDiv=function(imagePath){
        $scope.displayCarousel=false;
	$scope.imgShow=imagePath;
        $scope.displayImage=true;
  
  }
 }

$('.carousel').carousel({
    
}).on('slid.bs.carousel', function () {
     curSlide = $('.active');
    if(curSlide.is( ':first-child' )) {
     $('.left').hide();
     $('.right').show();    
     return;
    } else {
     $('.left').show();   
    }
    if (curSlide.is( ':last-child' )) {
     $('.right').hide();
     return;
    } else {
     $('.right').show();    
    }
  });

